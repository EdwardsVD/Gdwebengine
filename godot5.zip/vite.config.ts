import path from "path";
import { fileURLToPath } from "url";
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// COOP/COEP headers required for Godot 4 SharedArrayBuffer (threading)
const godotHeaders = {
  "Cross-Origin-Opener-Policy": "same-origin",
  "Cross-Origin-Embedder-Policy": "require-corp",
};

// https://vite.dev/config/
export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "src"),
    },
  },
  server: {
    // Only enable COOP/COEP in live mode to avoid breaking dev
    headers: process.env.VITE_GODOT_MODE === "live" ? godotHeaders : {},
  },
  preview: {
    headers: godotHeaders,
  },
});
