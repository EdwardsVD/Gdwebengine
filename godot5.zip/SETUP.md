# Setup

If you see a white screen, the most likely cause is stale `node_modules`.

Run these commands before starting:

```bash
rm -rf node_modules package-lock.json
npm install
npm run dev
```

## For Live Godot Mode (with SharedArrayBuffer threading)

```bash
VITE_GODOT_MODE=live npm run dev
```

## Godot Build

Export your Godot 4 project for Web (HTML5) and place files in `/public/godot-build/`.
