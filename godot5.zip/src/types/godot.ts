// ============================================================
// Godot ↔ React Message Payload Types
// ============================================================

// --- Actions React can send TO Godot ---

export type ReactToGodotAction =
  | "spawn_enemy"
  | "change_scene"
  | "pause"
  | "resume"
  | "update_difficulty"
  | "reset_game"
  | "player_input";

export interface SpawnEnemyPayload {
  position?: { x: number; y: number; z: number };
  type?: "basic" | "fast" | "tank";
  count?: number;
}

export interface ChangeScenePayload {
  scene: string;
}

export interface UpdateDifficultyPayload {
  level: number; // 1-10
  enemySpeed?: number;
  enemyHealth?: number;
  spawnRate?: number;
}

export interface PlayerInputPayload {
  action: string;
  pressed: boolean;
}

export type ReactToGodotPayload =
  | { action: "spawn_enemy"; data: SpawnEnemyPayload }
  | { action: "change_scene"; data: ChangeScenePayload }
  | { action: "pause"; data?: undefined }
  | { action: "resume"; data?: undefined }
  | { action: "reset_game"; data?: undefined }
  | { action: "update_difficulty"; data: UpdateDifficultyPayload }
  | { action: "player_input"; data: PlayerInputPayload };

// --- Events Godot sends TO React ---

export type GodotToReactEvent =
  | "score_update"
  | "health_update"
  | "player_position"
  | "enemy_count"
  | "fps_update"
  | "game_over"
  | "game_ready"
  | "enemy_killed"
  | "damage_taken"
  | "level_complete";

export interface ScoreUpdatePayload {
  score: number;
  combo: number;
}

export interface HealthUpdatePayload {
  health: number;
  maxHealth: number;
}

export interface PlayerPositionPayload {
  x: number;
  y: number;
  z: number;
}

export interface EnemyCountPayload {
  count: number;
  maxEnemies: number;
}

export interface FPSUpdatePayload {
  fps: number;
}

export interface GameOverPayload {
  finalScore: number;
  enemiesKilled: number;
  survivalTime: number;
}

export interface EnemyKilledPayload {
  points: number;
  enemyType: string;
  position: { x: number; y: number; z: number };
}

export interface DamageTakenPayload {
  damage: number;
  source: string;
  remainingHealth: number;
}

export interface LevelCompletePayload {
  level: number;
  score: number;
  time: number;
}

export interface GodotMessage {
  source: "godot";
  event: GodotToReactEvent;
  data: Record<string, unknown>;
}

// --- Game State ---

export interface GameState {
  score: number;
  combo: number;
  health: number;
  maxHealth: number;
  playerPosition: { x: number; y: number; z: number };
  enemyCount: number;
  maxEnemies: number;
  fps: number;
  isRunning: boolean;
  isPaused: boolean;
  isReady: boolean;
  difficulty: number;
  enemiesKilled: number;
  survivalTime: number;
}

export const initialGameState: GameState = {
  score: 0,
  combo: 0,
  health: 100,
  maxHealth: 100,
  playerPosition: { x: 0, y: 0, z: 0 },
  enemyCount: 0,
  maxEnemies: 20,
  fps: 0,
  isRunning: false,
  isPaused: false,
  isReady: false,
  difficulty: 1,
  enemiesKilled: 0,
  survivalTime: 0,
};

// --- GodotPlayer Ref ---

export interface GodotPlayerRef {
  sendToGodot: <T extends ReactToGodotPayload>(
    action: T["action"],
    data?: T["data"]
  ) => void;
  isReady: boolean;
  iframe: HTMLIFrameElement | null;
}
