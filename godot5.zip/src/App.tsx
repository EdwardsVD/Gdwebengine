import { useState, useMemo } from "react";
import GodotPlayer from "@/components/GodotPlayer";
import { GameHUD } from "@/components/HUD/GameHUD";
import { useGodot } from "@/hooks/useGodot";
import { useSimulatedGodot } from "@/hooks/useSimulatedGodot";
import { Menubar } from "@/components/editor/Menubar";
import { SceneTree } from "@/components/editor/SceneTree";
import { Inspector } from "@/components/editor/Inspector";
import { OutputLog } from "@/components/editor/OutputLog";
import { Viewport } from "@/components/editor/Viewport";
import { Minimap } from "@/components/editor/Minimap";
import { ControlButtons } from "@/components/editor/ControlButtons";
import type { GameState } from "@/types/godot";

/**
 * Godot 4 Editor Clone with embedded game viewport
 */
export default function App() {
  // Set to false to use actual Godot build
  const [useSimulation, setUseSimulation] = useState(false);

  return (
    <div className="w-screen h-screen flex flex-col overflow-hidden" style={{ background: "var(--godot-bg)" }}>
      {useSimulation ? (
        <SimulatedEditor onSwitchMode={() => setUseSimulation(false)} />
      ) : (
        <LiveEditor onSwitchMode={() => setUseSimulation(true)} />
      )}
    </div>
  );
}

/** Live mode: actual Godot iframe */
function LiveEditor({ onSwitchMode }: { onSwitchMode: () => void }) {
  const {
    gameState,
    godotRef,
    spawnEnemy,
    pauseGame,
    resumeGame,
    resetGame,
    setDifficulty,
  } = useGodot();

  const [selectedNode, setSelectedNode] = useState<string | null>("player");

  const handlePlay = () => {
    if (gameState.isPaused) {
      resumeGame();
    }
  };

  const handlePause = () => {
    if (gameState.isRunning && !gameState.isPaused) {
      pauseGame();
    } else if (gameState.isPaused) {
      resumeGame();
    }
  };

  return (
    <EditorLayout
      gameState={gameState}
      selectedNode={selectedNode}
      onSelectNode={setSelectedNode}
      onPlay={handlePlay}
      onPause={handlePause}
      onStop={resetGame}
      onSetDifficulty={setDifficulty}
      onSpawnEnemy={spawnEnemy}
      onReset={resetGame}
      isSimulation={false}
      onToggleMode={onSwitchMode}
    >
      <GodotPlayer
        ref={godotRef}
        src="/godot-build/index.html"
        onReady={() => console.log("[React] Godot game ready!")}
        onError={(err) => console.error("[React] Godot error:", err)}
      />
      <GameHUD gameState={gameState} />
    </EditorLayout>
  );
}

/** Simulated mode: 3D canvas simulation with HUD overlay */
function SimulatedEditor({ onSwitchMode }: { onSwitchMode: () => void }) {
  const {
    gameState,
    spawnEnemy,
    pauseGame,
    resumeGame,
    resetGame,
    setDifficulty,
  } = useSimulatedGodot();

  const [selectedNode, setSelectedNode] = useState<string | null>("player");

  const handlePlay = () => {
    if (gameState.isPaused) {
      resumeGame();
    }
  };

  const handlePause = () => {
    if (gameState.isRunning && !gameState.isPaused) {
      pauseGame();
    } else if (gameState.isPaused) {
      resumeGame();
    }
  };

  return (
    <EditorLayout
      gameState={gameState}
      selectedNode={selectedNode}
      onSelectNode={setSelectedNode}
      onPlay={handlePlay}
      onPause={handlePause}
      onStop={resetGame}
      onSetDifficulty={setDifficulty}
      onSpawnEnemy={spawnEnemy}
      onReset={resetGame}
      isSimulation={true}
      onToggleMode={onSwitchMode}
    >
      <SimulatedViewport gameState={gameState} />
      <GameHUD gameState={gameState} />
    </EditorLayout>
  );
}

/** Main editor layout */
function EditorLayout({
  children,
  gameState,
  selectedNode,
  onSelectNode,
  onPlay,
  onPause,
  onStop,
  onSetDifficulty,
  onSpawnEnemy,
  onReset,
  isSimulation,
  onToggleMode,
}: {
  children: React.ReactNode;
  gameState: GameState;
  selectedNode: string | null;
  onSelectNode: (id: string) => void;
  onPlay: () => void;
  onPause: () => void;
  onStop: () => void;
  onSetDifficulty: (level: number) => void;
  onSpawnEnemy: (type: "basic" | "fast" | "tank") => void;
  onReset: () => void;
  isSimulation: boolean;
  onToggleMode: () => void;
}) {
  return (
    <>
      {/* Top menubar */}
      <Menubar
        isRunning={gameState.isRunning}
        isPaused={gameState.isPaused}
        fps={gameState.fps}
        onPlay={onPlay}
        onPause={onPause}
        onStop={onStop}
      />

      {/* Main content area */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left sidebar - Scene Tree */}
        <div className="w-56 flex flex-col border-r border-[var(--godot-border)]">
          <div className="flex-1 overflow-hidden">
            <SceneTree
              selectedNode={selectedNode}
              onSelectNode={onSelectNode}
              enemyCount={gameState.enemyCount}
            />
          </div>
          {/* Minimap at bottom of left sidebar */}
          <div className="border-t border-[var(--godot-border)] p-2">
            <Minimap
              playerPosition={gameState.playerPosition}
              enemyCount={gameState.enemyCount}
            />
          </div>
        </div>

        {/* Center - Viewport */}
        <div className="flex-1 flex flex-col overflow-hidden">
          <div className="flex-1 overflow-hidden">
            <Viewport
              isSimulation={isSimulation}
              isRunning={gameState.isRunning}
              isPaused={gameState.isPaused}
              onToggleMode={onToggleMode}
            >
              {children}
            </Viewport>
          </div>

          {/* Bottom panel - Output */}
          <div className="h-36 border-t border-[var(--godot-border)]">
            <OutputLog gameState={gameState} />
          </div>
        </div>

        {/* Right sidebar - Inspector */}
        <div className="w-64 flex flex-col border-l border-[var(--godot-border)]">
          <div className="flex-1 overflow-hidden">
            <Inspector
              selectedNode={selectedNode}
              gameState={gameState}
              onSetDifficulty={onSetDifficulty}
            />
          </div>
          {/* Control buttons at bottom */}
          <div className="border-t border-[var(--godot-border)]">
            <ControlButtons onSpawnEnemy={onSpawnEnemy} onReset={onReset} />
          </div>
        </div>
      </div>

      {/* Mode toggle button */}
      <button
        onClick={onToggleMode}
        className="absolute bottom-40 right-72 z-50 godot-btn text-[10px]"
      >
        {isSimulation ? "📡 Live Mode" : "🎮 Simulation"}
      </button>
    </>
  );
}

/** Simulated 3D-like viewport for demo */
function SimulatedViewport({ gameState }: { gameState: GameState }) {
  const { playerPosition, enemyCount, difficulty } = gameState;
  const t = playerPosition.x * 0.067;

  // Pre-generate random values (stable)
  const windowPatterns = useMemo(() => {
    return Array.from({ length: 8 }, () =>
      Array.from({ length: 10 }, (_, j) => (j * 137) % 3 !== 0)
    );
  }, []);

  return (
    <div className="absolute inset-0 overflow-hidden" style={{ background: "#0d1117" }}>
      {/* Sky gradient */}
      <div 
        className="absolute inset-0"
        style={{
          background: "linear-gradient(to bottom, #0a0a15 0%, #151525 50%, #1a1a2a 100%)"
        }}
      />

      {/* Stars */}
      <div className="absolute inset-0">
        {Array.from({ length: 40 }, (_, i) => (
          <div
            key={`star-${i}`}
            className="absolute w-0.5 h-0.5 bg-white rounded-full"
            style={{
              left: `${(Math.sin(i * 73.7) * 0.5 + 0.5) * 100}%`,
              top: `${(Math.cos(i * 41.3) * 0.5 + 0.5) * 35}%`,
              opacity: 0.2 + Math.sin(i * 17 + t * 2) * 0.2,
            }}
          />
        ))}
      </div>

      {/* Ground plane */}
      <div className="absolute bottom-0 left-0 right-0 h-1/2" style={{ perspective: "600px" }}>
        <div
          className="absolute inset-0"
          style={{
            background: "linear-gradient(to top, rgba(37, 37, 55, 0.8), transparent)",
            transform: "rotateX(60deg)",
            transformOrigin: "bottom",
          }}
        >
          {/* Grid */}
          {Array.from({ length: 15 }, (_, i) => (
            <div
              key={`grid-h-${i}`}
              className="absolute left-0 right-0 border-t"
              style={{ 
                top: `${i * 7}%`,
                borderColor: "rgba(71, 140, 191, 0.15)"
              }}
            />
          ))}
          {Array.from({ length: 15 }, (_, i) => (
            <div
              key={`grid-v-${i}`}
              className="absolute top-0 bottom-0 border-l"
              style={{ 
                left: `${i * 7}%`,
                borderColor: "rgba(71, 140, 191, 0.15)"
              }}
            />
          ))}
        </div>
      </div>

      {/* Buildings */}
      {Array.from({ length: 6 }, (_, i) => {
        const x = (Math.sin(i * 2.1 + t * 0.05) * 0.5 + 0.5) * 70 + 15;
        const depth = Math.cos(i * 1.7) * 0.5 + 0.5;
        const height = 30 + depth * 60;
        const width = 15 + depth * 25;
        const bottom = 8 + depth * 12;
        return (
          <div
            key={`building-${i}`}
            className="absolute"
            style={{
              left: `${x}%`,
              bottom: `${bottom}%`,
              width: `${width}px`,
              height: `${height}px`,
              background: `linear-gradient(to top, rgba(30,30,46,0.9), rgba(37,37,55,0.7))`,
              border: "1px solid rgba(71, 140, 191, 0.2)",
              transform: `translateX(-50%) scale(${0.5 + depth * 0.5})`,
            }}
          >
            {Array.from({ length: Math.floor(height / 12) }, (_, j) => (
              <div
                key={j}
                className="mx-auto mt-1.5"
                style={{
                  width: "50%",
                  height: "3px",
                  background: windowPatterns[i]?.[j] ? "rgba(229, 192, 123, 0.4)" : "transparent",
                }}
              />
            ))}
          </div>
        );
      })}

      {/* Player */}
      <div
        className="absolute transition-all duration-300"
        style={{
          left: `${50 + Math.sin(playerPosition.x * 0.067) * 8}%`,
          bottom: "22%",
          transform: "translateX(-50%)",
        }}
      >
        <div className="relative">
          <div 
            className="w-4 h-6 mx-auto rounded-t"
            style={{ background: "linear-gradient(to top, #3d6e8a, #478cbf)" }}
          />
          <div 
            className="w-3 h-3 mx-auto -mt-0.5 rounded-full"
            style={{ background: "#5a9fd4" }}
          />
          <div 
            className="absolute -inset-3 rounded-full blur-md"
            style={{ background: "rgba(71, 140, 191, 0.2)" }}
          />
        </div>
      </div>

      {/* Enemies */}
      {Array.from({ length: Math.min(enemyCount, 5) }, (_, i) => (
        <div
          key={`enemy-${i}`}
          className="absolute animate-pulse"
          style={{
            left: `${18 + i * 15 + Math.sin(t + i * 2) * 3}%`,
            bottom: `${26 + Math.cos(t + i * 1.5) * 3}%`,
          }}
        >
          <div className="relative">
            <div 
              className="w-3 h-4 mx-auto rounded-t"
              style={{ background: "linear-gradient(to top, #8a2020, #e06c75)" }}
            />
            <div 
              className="w-2 h-2 mx-auto -mt-0.5 rounded-full"
              style={{ background: "#e06c75" }}
            />
          </div>
        </div>
      ))}

      {/* Difficulty atmosphere */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: `radial-gradient(circle at 50% 100%, transparent 40%, rgba(224, 108, 117, ${difficulty * 0.015}) 100%)`,
        }}
      />
    </div>
  );
}
