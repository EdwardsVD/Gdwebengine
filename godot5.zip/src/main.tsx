import { StrictMode, Component, type ReactNode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

class ErrorBoundary extends Component<{ children: ReactNode }, ErrorBoundaryState> {
  constructor(props: { children: ReactNode }) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div
          style={{
            background: "#1e1e2e",
            color: "#e06c75",
            padding: "2rem",
            fontFamily: "ui-monospace, 'JetBrains Mono', monospace",
            minHeight: "100vh",
            whiteSpace: "pre-wrap",
          }}
        >
          <h2 style={{ color: "#e5c07b", marginBottom: "1rem" }}>
            🔴 React Error
          </h2>
          <p style={{ color: "#dddddd", marginTop: "1rem" }}>
            {this.state.error?.message}
          </p>
          <pre
            style={{
              marginTop: "1rem",
              fontSize: "12px",
              color: "#8888aa",
              overflowX: "auto",
            }}
          >
            {this.state.error?.stack}
          </pre>
          <button
            onClick={() => window.location.reload()}
            style={{
              marginTop: "2rem",
              padding: "8px 16px",
              background: "#478cbf",
              color: "#fff",
              border: "none",
              borderRadius: "4px",
              fontFamily: "inherit",
              cursor: "pointer",
            }}
          >
            ↻ Reload Page
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </StrictMode>
);
