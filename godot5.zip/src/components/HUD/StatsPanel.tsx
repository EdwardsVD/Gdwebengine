import { cn } from "@/utils/cn";

interface StatsPanelProps {
  fps: number;
  enemyCount: number;
  maxEnemies: number;
  playerPosition: { x: number; y: number; z: number };
  difficulty: number;
  enemiesKilled: number;
}

export function StatsPanel({
  fps,
  enemyCount,
  maxEnemies,
  playerPosition,
  difficulty,
  enemiesKilled,
}: StatsPanelProps) {
  return (
    <div className="bg-black/60 backdrop-blur-sm rounded-lg border border-gray-700/50 p-3 space-y-2 font-mono text-xs">
      <div className="text-gray-400 tracking-widest text-[10px] mb-2 border-b border-gray-700/50 pb-1">
        TELEMETRY
      </div>
      <div className="flex justify-between">
        <span className="text-gray-500">FPS</span>
        <span
          className={cn(
            "tabular-nums font-bold",
            fps >= 55 ? "text-green-400" : fps >= 30 ? "text-yellow-400" : "text-red-400"
          )}
        >
          {fps}
        </span>
      </div>
      <div className="flex justify-between">
        <span className="text-gray-500">ENEMIES</span>
        <span className="text-orange-400 tabular-nums">
          {enemyCount}/{maxEnemies}
        </span>
      </div>
      <div className="flex justify-between">
        <span className="text-gray-500">KILLED</span>
        <span className="text-red-400 tabular-nums">💀 {enemiesKilled}</span>
      </div>
      <div className="flex justify-between">
        <span className="text-gray-500">DIFF</span>
        <span className="text-purple-400 tabular-nums">LV.{difficulty}</span>
      </div>
      <div className="border-t border-gray-700/50 pt-2">
        <span className="text-gray-500">POS</span>
        <div className="text-cyan-400/70 text-[10px] tabular-nums mt-0.5">
          X:{playerPosition.x.toFixed(1)} Y:{playerPosition.y.toFixed(1)} Z:
          {playerPosition.z.toFixed(1)}
        </div>
      </div>
    </div>
  );
}
