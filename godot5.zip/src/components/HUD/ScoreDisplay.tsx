import { cn } from "@/utils/cn";

interface ScoreDisplayProps {
  score: number;
  combo: number;
}

export function ScoreDisplay({ score, combo }: ScoreDisplayProps) {
  return (
    <div className="text-right">
      <div className="flex items-center justify-end gap-2">
        <span className="text-xs font-mono text-gray-400 tracking-wider">SCORE</span>
        <span className="text-2xl font-mono font-bold text-cyan-400 tabular-nums">
          {score.toLocaleString().padStart(8, "0")}
        </span>
      </div>
      {combo > 1 && (
        <div
          className={cn(
            "flex items-center justify-end gap-1 mt-1",
            combo >= 10
              ? "animate-pulse"
              : ""
          )}
        >
          <span className="text-lg">🔥</span>
          <span
            className={cn(
              "text-sm font-mono font-bold",
              combo >= 10
                ? "text-orange-400"
                : combo >= 5
                ? "text-yellow-400"
                : "text-gray-300"
            )}
          >
            x{combo} COMBO
          </span>
        </div>
      )}
    </div>
  );
}
