import { cn } from "@/utils/cn";

interface ControlPanelProps {
  isPaused: boolean;
  difficulty: number;
  onPause: () => void;
  onResume: () => void;
  onSpawnEnemy: (type: "basic" | "fast" | "tank") => void;
  onSetDifficulty: (level: number) => void;
  onReset: () => void;
}

export function ControlPanel({
  isPaused,
  difficulty,
  onPause,
  onResume,
  onSpawnEnemy,
  onSetDifficulty,
  onReset,
}: ControlPanelProps) {
  return (
    <div className="bg-black/70 backdrop-blur-sm rounded-lg border border-gray-700/50 p-3 space-y-3 font-mono text-xs">
      <div className="text-gray-400 tracking-widest text-[10px] border-b border-gray-700/50 pb-1">
        CONTROLS
      </div>

      {/* Pause / Resume */}
      <button
        onClick={isPaused ? onResume : onPause}
        className={cn(
          "w-full py-2 px-3 rounded font-bold text-xs tracking-wider transition-all",
          isPaused
            ? "bg-green-600/80 hover:bg-green-500 text-white border border-green-500/50"
            : "bg-yellow-600/80 hover:bg-yellow-500 text-white border border-yellow-500/50"
        )}
      >
        {isPaused ? "▶ RESUME" : "⏸ PAUSE"}
      </button>

      {/* Spawn Enemies */}
      <div>
        <div className="text-gray-500 mb-1.5">SPAWN ENEMY</div>
        <div className="grid grid-cols-3 gap-1">
          <button
            onClick={() => onSpawnEnemy("basic")}
            className="py-1.5 px-1 bg-red-900/60 hover:bg-red-800 text-red-300 rounded border border-red-800/50 transition-colors text-[10px]"
          >
            👾 BASIC
          </button>
          <button
            onClick={() => onSpawnEnemy("fast")}
            className="py-1.5 px-1 bg-orange-900/60 hover:bg-orange-800 text-orange-300 rounded border border-orange-800/50 transition-colors text-[10px]"
          >
            ⚡ FAST
          </button>
          <button
            onClick={() => onSpawnEnemy("tank")}
            className="py-1.5 px-1 bg-purple-900/60 hover:bg-purple-800 text-purple-300 rounded border border-purple-800/50 transition-colors text-[10px]"
          >
            🛡 TANK
          </button>
        </div>
      </div>

      {/* Difficulty */}
      <div>
        <div className="flex justify-between items-center mb-1.5">
          <span className="text-gray-500">DIFFICULTY</span>
          <span className="text-purple-400 font-bold">{difficulty}</span>
        </div>
        <input
          type="range"
          min={1}
          max={10}
          value={difficulty}
          onChange={(e) => onSetDifficulty(parseInt(e.target.value))}
          className="w-full h-1.5 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-purple-500"
        />
        <div className="flex justify-between text-[9px] text-gray-600 mt-0.5">
          <span>EASY</span>
          <span>NIGHTMARE</span>
        </div>
      </div>

      {/* Reset */}
      <button
        onClick={onReset}
        className="w-full py-2 px-3 bg-gray-800 hover:bg-red-900/60 text-gray-400 hover:text-red-400 rounded border border-gray-700/50 hover:border-red-800/50 font-bold text-xs tracking-wider transition-all"
      >
        ↻ RESET GAME
      </button>
    </div>
  );
}
