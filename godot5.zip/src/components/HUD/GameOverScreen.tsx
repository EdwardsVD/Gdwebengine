interface GameOverScreenProps {
  score: number;
  enemiesKilled: number;
  survivalTime: number;
  onRestart: () => void;
}

export function GameOverScreen({
  score,
  enemiesKilled,
  survivalTime,
  onRestart,
}: GameOverScreenProps) {
  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  };

  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm">
      <div className="text-center space-y-6 animate-fade-in">
        <div className="space-y-2">
          <h1 className="text-6xl font-bold text-red-500 font-mono tracking-wider animate-pulse">
            GAME OVER
          </h1>
          <div className="w-64 h-0.5 bg-gradient-to-r from-transparent via-red-500 to-transparent mx-auto" />
        </div>

        <div className="bg-black/60 border border-gray-700/50 rounded-lg p-6 space-y-4 font-mono">
          <div className="flex justify-between items-center">
            <span className="text-gray-500 text-sm">FINAL SCORE</span>
            <span className="text-3xl font-bold text-cyan-400">
              {score.toLocaleString()}
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-500 text-sm">ENEMIES KILLED</span>
            <span className="text-xl font-bold text-red-400">
              💀 {enemiesKilled}
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-500 text-sm">SURVIVAL TIME</span>
            <span className="text-xl font-bold text-green-400">
              ⏱ {formatTime(survivalTime)}
            </span>
          </div>
        </div>

        <button
          onClick={onRestart}
          className="px-8 py-3 bg-gradient-to-r from-cyan-600 to-purple-600 hover:from-cyan-500 hover:to-purple-500 text-white font-mono font-bold tracking-wider rounded-lg border border-cyan-500/30 transition-all transform hover:scale-105 active:scale-95"
        >
          ↻ PLAY AGAIN
        </button>
      </div>
    </div>
  );
}
