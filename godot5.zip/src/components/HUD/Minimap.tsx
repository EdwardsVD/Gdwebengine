interface MinimapProps {
  playerPosition: { x: number; y: number; z: number };
  enemyCount: number;
}

export function Minimap({ playerPosition, enemyCount }: MinimapProps) {
  // Simple minimap visualization
  const mapSize = 100;
  const scale = 2; // units per pixel
  const px = ((playerPosition.x / scale) + mapSize / 2) % mapSize;
  const pz = ((playerPosition.z / scale) + mapSize / 2) % mapSize;

  // Generate pseudo-random enemy positions based on count
  const enemies = Array.from({ length: Math.min(enemyCount, 8) }, (_, i) => ({
    x: ((Math.sin(i * 137.5) * 0.5 + 0.5) * mapSize * 0.8) + mapSize * 0.1,
    y: ((Math.cos(i * 137.5) * 0.5 + 0.5) * mapSize * 0.8) + mapSize * 0.1,
  }));

  return (
    <div className="relative w-28 h-28 bg-black/70 border border-gray-600/50 rounded-lg overflow-hidden">
      {/* Grid lines */}
      <div className="absolute inset-0 opacity-20">
        {[0.25, 0.5, 0.75].map((pos) => (
          <div key={`h-${pos}`}>
            <div className="absolute bg-gray-500" style={{ top: `${pos * 100}%`, left: 0, right: 0, height: 1 }} />
            <div className="absolute bg-gray-500" style={{ left: `${pos * 100}%`, top: 0, bottom: 0, width: 1 }} />
          </div>
        ))}
      </div>

      {/* Enemy dots */}
      {enemies.map((enemy, i) => (
        <div
          key={i}
          className="absolute w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse"
          style={{
            left: `${(enemy.x / mapSize) * 100}%`,
            top: `${(enemy.y / mapSize) * 100}%`,
          }}
        />
      ))}

      {/* Player dot */}
      <div
        className="absolute w-2.5 h-2.5 bg-cyan-400 rounded-full border border-white/50 transition-all duration-300 z-10"
        style={{
          left: `${(px / mapSize) * 100}%`,
          top: `${(pz / mapSize) * 100}%`,
          transform: "translate(-50%, -50%)",
        }}
      />

      {/* Label */}
      <div className="absolute bottom-0.5 right-1 text-[8px] font-mono text-gray-500">MAP</div>
    </div>
  );
}
