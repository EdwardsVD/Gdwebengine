import { cn } from "@/utils/cn";

interface HealthBarProps {
  health: number;
  maxHealth: number;
}

export function HealthBar({ health, maxHealth }: HealthBarProps) {
  const percentage = Math.max(0, Math.min(100, (health / maxHealth) * 100));
  const isLow = percentage <= 25;
  const isMedium = percentage > 25 && percentage <= 50;

  return (
    <div className="flex items-center gap-3">
      <div className="text-2xl">{isLow ? "💔" : "❤️"}</div>
      <div className="flex-1">
        <div className="flex justify-between items-center mb-1">
          <span className="text-xs font-mono text-gray-300 tracking-wider">HEALTH</span>
          <span
            className={cn(
              "text-xs font-mono font-bold",
              isLow ? "text-red-400" : isMedium ? "text-yellow-400" : "text-green-400"
            )}
          >
            {Math.round(health)} / {maxHealth}
          </span>
        </div>
        <div className="w-48 h-3 bg-gray-800/80 rounded-full overflow-hidden border border-gray-700/50">
          <div
            className={cn(
              "h-full rounded-full transition-all duration-300 ease-out",
              isLow
                ? "bg-gradient-to-r from-red-700 to-red-500 animate-pulse"
                : isMedium
                ? "bg-gradient-to-r from-yellow-700 to-yellow-500"
                : "bg-gradient-to-r from-green-700 to-green-500"
            )}
            style={{ width: `${percentage}%` }}
          />
        </div>
      </div>
    </div>
  );
}
