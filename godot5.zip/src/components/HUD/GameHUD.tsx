import type { GameState } from "@/types/godot";

interface GameHUDProps {
  gameState: GameState;
}

export function GameHUD({ gameState }: GameHUDProps) {
  const healthPercent = (gameState.health / gameState.maxHealth) * 100;

  return (
    <div className="absolute inset-0 pointer-events-none z-20">
      {/* Minimal Godot-style debug HUD */}
      
      {/* Health bar - top left */}
      <div className="absolute top-3 left-3">
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-white/70 font-mono">HP</span>
          <div className="w-32 h-1.5 bg-black/50 rounded-sm overflow-hidden">
            <div
              className="h-full transition-all duration-300"
              style={{
                width: `${healthPercent}%`,
                background: healthPercent > 50 
                  ? "linear-gradient(90deg, #4a7c4e, #6aab73)"
                  : healthPercent > 25
                  ? "linear-gradient(90deg, #8a6c20, #e5c07b)"
                  : "linear-gradient(90deg, #8a2020, #e06c75)",
              }}
            />
          </div>
          <span className="text-[10px] text-white/90 font-mono tabular-nums">
            {Math.round(gameState.health)}
          </span>
        </div>
      </div>

      {/* Score - top right */}
      <div className="absolute top-3 right-3">
        <div className="text-right">
          <div className="text-white/90 font-mono text-sm tabular-nums">
            {gameState.score.toString().padStart(8, "0")}
          </div>
          {gameState.combo > 1 && (
            <div className="text-[10px] text-[#e5c07b] font-mono">
              x{gameState.combo} COMBO
            </div>
          )}
        </div>
      </div>

      {/* Crosshair - center */}
      {gameState.isRunning && !gameState.isPaused && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="relative w-4 h-4">
            <div className="absolute top-1/2 left-0 right-0 h-px bg-white/60" />
            <div className="absolute left-1/2 top-0 bottom-0 w-px bg-white/60" />
            <div className="absolute top-1/2 left-1/2 w-1 h-1 -mt-0.5 -ml-0.5 rounded-full bg-white/80" />
          </div>
        </div>
      )}

      {/* Enemy counter - bottom left */}
      <div className="absolute bottom-3 left-3">
        <div className="text-[10px] text-white/70 font-mono">
          👾 {gameState.enemyCount}/{gameState.maxEnemies}
        </div>
      </div>

      {/* Pause overlay */}
      {gameState.isPaused && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/40">
          <div className="text-white font-mono text-xl tracking-widest">
            ⏸ PAUSED
          </div>
        </div>
      )}

      {/* Game over overlay */}
      {!gameState.isRunning && gameState.score > 0 && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/60">
          <div className="text-center font-mono">
            <div className="text-[#e06c75] text-2xl mb-2">GAME OVER</div>
            <div className="text-white/80 text-sm">
              Score: {gameState.score.toLocaleString()}
            </div>
            <div className="text-white/60 text-xs mt-1">
              Enemies killed: {gameState.enemiesKilled}
            </div>
          </div>
        </div>
      )}

      {/* Low health warning */}
      {gameState.health <= 25 && gameState.isRunning && (
        <div 
          className="absolute inset-0 pointer-events-none animate-pulse-glow"
          style={{
            boxShadow: "inset 0 0 60px rgba(224, 108, 117, 0.3)",
          }}
        />
      )}
    </div>
  );
}
