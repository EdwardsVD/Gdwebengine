export function Crosshair() {
  return (
    <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-20">
      <div className="relative w-8 h-8">
        {/* Center dot */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-1 h-1 bg-white/80 rounded-full" />
        </div>
        {/* Top */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-0.5 h-2.5 bg-white/60" />
        {/* Bottom */}
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0.5 h-2.5 bg-white/60" />
        {/* Left */}
        <div className="absolute left-0 top-1/2 -translate-y-1/2 w-2.5 h-0.5 bg-white/60" />
        {/* Right */}
        <div className="absolute right-0 top-1/2 -translate-y-1/2 w-2.5 h-0.5 bg-white/60" />
      </div>
    </div>
  );
}
