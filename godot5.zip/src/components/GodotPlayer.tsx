import {
  forwardRef,
  useCallback,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from "react";
import type { GodotPlayerRef, ReactToGodotPayload } from "@/types/godot";

interface GodotPlayerProps {
  src?: string;
  className?: string;
  onReady?: () => void;
  onError?: (error: string) => void;
}

const GodotPlayer = forwardRef<GodotPlayerRef, GodotPlayerProps>(
  (
    {
      src = "/godot-build/index.html",
      className = "",
      onReady,
      onError,
    },
    ref
  ) => {
    const iframeRef = useRef<HTMLIFrameElement>(null);
    const [isReady, setIsReady] = useState(false);
    const [isLoading, setIsLoading] = useState(true);
    const [loadError, setLoadError] = useState<string | null>(null);
    
    // Stable refs to avoid stale closures
    const onReadyRef = useRef(onReady);
    const onErrorRef = useRef(onError);
    onReadyRef.current = onReady;
    onErrorRef.current = onError;

    // Listen for ready signal from Godot
    useEffect(() => {
      const handleMessage = (event: MessageEvent) => {
        if (event.data?.source === "godot" && event.data?.event === "game_ready") {
          setIsReady(true);
          setIsLoading(false);
          onReadyRef.current?.();
        }
      };

      window.addEventListener("message", handleMessage);
      return () => window.removeEventListener("message", handleMessage);
    }, []);

    // Send message to Godot iframe
    const sendToGodot = useCallback(
      <T extends ReactToGodotPayload>(action: T["action"], data?: T["data"]) => {
        if (iframeRef.current?.contentWindow) {
          const message = {
            source: "react",
            action,
            data: data ?? {},
          };
          iframeRef.current.contentWindow.postMessage(message, "*");
        }
      },
      []
    );

    // Expose ref API
    useImperativeHandle(
      ref,
      () => ({
        sendToGodot,
        isReady,
        iframe: iframeRef.current,
      }),
      [sendToGodot, isReady]
    );

    const handleIframeLoad = () => {
      setIsLoading(false);
    };

    const handleIframeError = () => {
      const errorMsg = "Failed to load Godot build. Make sure the build exists at /public/godot-build/";
      setLoadError(errorMsg);
      setIsLoading(false);
      onErrorRef.current?.(errorMsg);
    };

    return (
      <div className={`relative w-full h-full ${className}`}>
        {/* Loading overlay - Godot style */}
        {isLoading && (
          <div 
            className="absolute inset-0 z-10 flex flex-col items-center justify-center"
            style={{ background: "var(--godot-bg)" }}
          >
            <div className="relative w-12 h-12">
              <div 
                className="absolute inset-0 border-2 rounded-full animate-spin"
                style={{ 
                  borderColor: "var(--godot-border)",
                  borderTopColor: "var(--godot-accent)"
                }}
              />
            </div>
            <p 
              className="mt-4 font-mono text-xs animate-pulse"
              style={{ color: "var(--godot-text-dim)" }}
            >
              Loading Godot Engine...
            </p>
          </div>
        )}

        {/* Error overlay */}
        {loadError && (
          <div 
            className="absolute inset-0 z-10 flex flex-col items-center justify-center p-8"
            style={{ background: "var(--godot-bg)" }}
          >
            <div className="text-4xl mb-4">⚠️</div>
            <p className="font-mono text-center text-sm" style={{ color: "var(--godot-error)" }}>
              {loadError}
            </p>
            <p className="font-mono text-xs mt-4 text-center" style={{ color: "var(--godot-text-muted)" }}>
              Export your Godot 4 project for Web (HTML5) and place files in{" "}
              <code style={{ color: "var(--godot-accent)" }}>/public/godot-build/</code>
            </p>
          </div>
        )}

        {/* Godot iframe - with pointer-lock permission */}
        <iframe
          ref={iframeRef}
          src={src}
          title="Godot Game"
          className="w-full h-full border-0"
          allow="autoplay; fullscreen; gamepad; pointer-lock; clipboard-write"
          sandbox="allow-scripts allow-same-origin allow-popups allow-pointer-lock"
          onLoad={handleIframeLoad}
          onError={handleIframeError}
          style={{ display: loadError ? "none" : "block" }}
        />
      </div>
    );
  }
);

GodotPlayer.displayName = "GodotPlayer";

export default GodotPlayer;
