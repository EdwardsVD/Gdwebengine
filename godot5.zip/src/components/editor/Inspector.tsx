import { useState } from "react";
import type { GameState } from "@/types/godot";

// Inline chevron components (no lucide-react)
const ChevronDown = () => <span className="text-[10px]">▼</span>;
const ChevronRight = () => <span className="text-[10px]">▶</span>;

interface InspectorProps {
  selectedNode: string | null;
  gameState: GameState;
  onSetDifficulty: (level: number) => void;
}

interface InspectorSection {
  title: string;
  icon: string;
  expanded: boolean;
  properties: {
    name: string;
    value: string | number;
    type: "string" | "number" | "vector3" | "color" | "bool";
    editable?: boolean;
  }[];
}

function getNodeProperties(nodeId: string | null, gameState: GameState): InspectorSection[] {
  if (!nodeId) {
    return [
      {
        title: "No Selection",
        icon: "ℹ️",
        expanded: true,
        properties: [
          { name: "hint", value: "Select a node", type: "string" },
        ],
      },
    ];
  }

  const baseProperties: InspectorSection[] = [
    {
      title: "Node",
      icon: "📦",
      expanded: true,
      properties: [
        { name: "name", value: nodeId, type: "string" },
        { name: "visible", value: "true", type: "bool" },
      ],
    },
  ];

  switch (nodeId) {
    case "player":
      return [
        ...baseProperties,
        {
          title: "CharacterBody3D",
          icon: "🎮",
          expanded: true,
          properties: [
            { name: "position", value: `(${gameState.playerPosition.x.toFixed(1)}, ${gameState.playerPosition.y.toFixed(1)}, ${gameState.playerPosition.z.toFixed(1)})`, type: "vector3" },
            { name: "velocity", value: "(0.0, 0.0, 0.0)", type: "vector3" },
            { name: "on_floor", value: "true", type: "bool" },
          ],
        },
        {
          title: "Player Script",
          icon: "📜",
          expanded: true,
          properties: [
            { name: "health", value: gameState.health, type: "number" },
            { name: "max_health", value: gameState.maxHealth, type: "number" },
            { name: "move_speed", value: 7.0, type: "number" },
            { name: "jump_velocity", value: 6.0, type: "number" },
          ],
        },
      ];
    case "gamemanager":
      return [
        ...baseProperties,
        {
          title: "GameManager",
          icon: "📊",
          expanded: true,
          properties: [
            { name: "score", value: gameState.score, type: "number" },
            { name: "combo", value: gameState.combo, type: "number" },
            { name: "difficulty", value: gameState.difficulty, type: "number", editable: true },
            { name: "is_running", value: gameState.isRunning ? "true" : "false", type: "bool" },
            { name: "is_paused", value: gameState.isPaused ? "true" : "false", type: "bool" },
          ],
        },
        {
          title: "Statistics",
          icon: "📈",
          expanded: true,
          properties: [
            { name: "enemies_killed", value: gameState.enemiesKilled, type: "number" },
            { name: "survival_time", value: gameState.survivalTime.toFixed(1), type: "number" },
            { name: "enemy_count", value: gameState.enemyCount, type: "number" },
          ],
        },
      ];
    case "spawner":
      return [
        ...baseProperties,
        {
          title: "EnemySpawner",
          icon: "👾",
          expanded: true,
          properties: [
            { name: "active_enemies", value: gameState.enemyCount, type: "number" },
            { name: "max_enemies", value: gameState.maxEnemies, type: "number" },
            { name: "spawn_rate", value: 2.0, type: "number" },
          ],
        },
      ];
    case "camera":
      return [
        ...baseProperties,
        {
          title: "Camera3D",
          icon: "📷",
          expanded: true,
          properties: [
            { name: "fov", value: 75, type: "number" },
            { name: "near", value: 0.05, type: "number" },
            { name: "far", value: 500, type: "number" },
            { name: "current", value: "true", type: "bool" },
          ],
        },
      ];
    case "world":
      return [
        ...baseProperties,
        {
          title: "World Script",
          icon: "🌍",
          expanded: true,
          properties: [
            { name: "arena_size", value: 50, type: "number" },
            { name: "wall_height", value: 5, type: "number" },
            { name: "obstacle_count", value: 15, type: "number" },
          ],
        },
      ];
    default:
      return baseProperties;
  }
}

function Section({
  section,
  gameState,
  onSetDifficulty,
}: {
  section: InspectorSection;
  gameState: GameState;
  onSetDifficulty: (level: number) => void;
}) {
  const [expanded, setExpanded] = useState(section.expanded);

  return (
    <div className="inspector-section">
      <div
        className="inspector-section-header"
        onClick={() => setExpanded(!expanded)}
      >
        {expanded ? <ChevronDown /> : <ChevronRight />}
        <span>{section.icon}</span>
        <span>{section.title}</span>
      </div>
      {expanded && (
        <div className="py-1">
          {section.properties.map((prop) => (
            <div key={prop.name} className="inspector-row">
              <span className="inspector-label">{prop.name}</span>
              {prop.editable && prop.name === "difficulty" ? (
                <div className="flex items-center gap-2">
                  <input
                    type="range"
                    min={1}
                    max={10}
                    value={gameState.difficulty}
                    onChange={(e) => onSetDifficulty(parseInt(e.target.value))}
                    className="godot-slider flex-1"
                  />
                  <span className="inspector-value w-6 text-right">
                    {gameState.difficulty}
                  </span>
                </div>
              ) : (
                <span
                  className="inspector-value"
                  style={{
                    color:
                      prop.type === "vector3"
                        ? "var(--godot-info)"
                        : prop.type === "bool"
                        ? prop.value === "true"
                          ? "var(--godot-green)"
                          : "var(--godot-error)"
                        : "var(--godot-text)",
                  }}
                >
                  {prop.value}
                </span>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export function Inspector({ selectedNode, gameState, onSetDifficulty }: InspectorProps) {
  const sections = getNodeProperties(selectedNode, gameState);

  return (
    <div className="godot-panel h-full flex flex-col">
      <div className="godot-panel-header">
        <span>🔧</span>
        <span>Inspector</span>
      </div>
      <div className="flex-1 overflow-auto">
        {sections.map((section, i) => (
          <Section
            key={i}
            section={section}
            gameState={gameState}
            onSetDifficulty={onSetDifficulty}
          />
        ))}
      </div>
    </div>
  );
}
