interface ControlButtonsProps {
  onSpawnEnemy: (type: "basic" | "fast" | "tank") => void;
  onReset: () => void;
}

export function ControlButtons({ onSpawnEnemy, onReset }: ControlButtonsProps) {
  return (
    <div className="godot-panel">
      <div className="godot-panel-header">
        <span>🎮</span>
        <span>Game Controls</span>
      </div>
      <div className="p-2 space-y-2">
        <div className="text-[10px] text-[var(--godot-text-dim)] mb-1">
          SPAWN ENEMY
        </div>
        <div className="grid grid-cols-3 gap-1">
          <button
            className="godot-btn flex flex-col items-center py-2"
            onClick={() => onSpawnEnemy("basic")}
          >
            <span className="text-[var(--godot-error)]">💀</span>
            <span className="text-[9px] mt-1">Basic</span>
          </button>
          <button
            className="godot-btn flex flex-col items-center py-2"
            onClick={() => onSpawnEnemy("fast")}
          >
            <span className="text-[var(--godot-warning)]">⚡</span>
            <span className="text-[9px] mt-1">Fast</span>
          </button>
          <button
            className="godot-btn flex flex-col items-center py-2"
            onClick={() => onSpawnEnemy("tank")}
          >
            <span className="text-[#c678dd]">🛡</span>
            <span className="text-[9px] mt-1">Tank</span>
          </button>
        </div>
        <button
          className="godot-btn w-full mt-2"
          onClick={onReset}
        >
          ↻ Reset Game
        </button>
      </div>
    </div>
  );
}
