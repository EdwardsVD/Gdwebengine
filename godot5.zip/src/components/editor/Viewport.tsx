import { ReactNode } from "react";

interface ViewportProps {
  children: ReactNode;
  isSimulation: boolean;
  isRunning: boolean;
  isPaused: boolean;
  onToggleMode: () => void;
}

export function Viewport({
  children,
  isSimulation,
  isRunning,
  isPaused,
}: ViewportProps) {
  const getBadgeClass = () => {
    if (!isRunning) return "stopped";
    if (isSimulation) return "simulation";
    return "running";
  };

  const getBadgeText = () => {
    if (!isRunning) return "STOPPED";
    if (isPaused) return "PAUSED";
    if (isSimulation) return "SIMULATION";
    return "RUNNING";
  };

  return (
    <div className="h-full flex flex-col bg-[var(--godot-bg)]">
      {/* Viewport header */}
      <div className="viewport-header">
        <div className="flex items-center gap-3">
          <span className="text-[var(--godot-text)]">Perspective</span>
          <span className="text-[var(--godot-text-muted)]">▾</span>
          <div className="flex items-center gap-1 ml-4">
            <button className="godot-btn-icon" title="Toggle Grid">
              <span>⊞</span>
            </button>
            <button className="godot-btn-icon" title="Camera Settings">
              <span>📷</span>
            </button>
            <button className="godot-btn-icon" title="Maximize">
              <span>⛶</span>
            </button>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className={`viewport-badge ${getBadgeClass()}`}>
            {getBadgeText()}
          </span>
        </div>
      </div>

      {/* Viewport content */}
      <div className="flex-1 relative overflow-hidden">
        {children}
        
        {/* Viewport corner info */}
        <div className="absolute bottom-2 left-2 text-[10px] text-[var(--godot-text-muted)] font-mono">
          3D View | Forward+
        </div>
      </div>
    </div>
  );
}
