interface MenubarProps {
  isRunning: boolean;
  isPaused: boolean;
  fps: number;
  onPlay: () => void;
  onPause: () => void;
  onStop: () => void;
}

export function Menubar({
  isRunning,
  isPaused,
  fps,
  onPlay,
  onPause,
  onStop,
}: MenubarProps) {
  return (
    <div className="godot-menubar">
      {/* Left menu items */}
      <div className="flex items-center">
        <div className="godot-menu-item">Scene</div>
        <div className="godot-menu-item">Project</div>
        <div className="godot-menu-item">Debug</div>
        <div className="godot-menu-item">Editor</div>
        <div className="godot-menu-item">Help</div>
      </div>

      {/* Center playtest controls */}
      <div className="godot-playtest-controls">
        <button
          className={`godot-play-btn ${isRunning && !isPaused ? "active" : ""}`}
          onClick={onPlay}
          title="Play Scene (F5)"
        >
          <span>▶</span>
        </button>
        <button
          className={`godot-play-btn ${isPaused ? "active" : ""}`}
          onClick={onPause}
          title="Pause (F6)"
          style={{ background: isPaused ? "var(--godot-warning)" : undefined }}
        >
          <span>⏸</span>
        </button>
        <button
          className="godot-play-btn"
          onClick={onStop}
          title="Stop (F8)"
        >
          <span>⏹</span>
        </button>
        <button
          className="godot-play-btn ml-1"
          onClick={onStop}
          title="Restart"
        >
          <span>↺</span>
        </button>
      </div>

      {/* Right side */}
      <div className="flex items-center gap-3 ml-auto">
        <div className="flex items-center gap-1">
          <span
            className="text-[11px] font-mono"
            style={{
              color:
                fps >= 55
                  ? "var(--godot-green)"
                  : fps >= 30
                  ? "var(--godot-warning)"
                  : "var(--godot-error)",
            }}
          >
            {fps} FPS
          </span>
        </div>
        <div className="text-[11px] text-[var(--godot-text-dim)]">
          Godot 4.2 (React Bridge)
        </div>
      </div>
    </div>
  );
}
