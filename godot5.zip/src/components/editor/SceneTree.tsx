import { useState } from "react";

// Inline chevron components (no lucide-react)
const ChevronDown = () => <span className="text-[10px]">▼</span>;
const ChevronRight = () => <span className="text-[10px]">▶</span>;

interface SceneNode {
  id: string;
  name: string;
  type: string;
  icon: string;
  iconColor: string;
  children?: SceneNode[];
  expanded?: boolean;
}

interface SceneTreeProps {
  selectedNode: string | null;
  onSelectNode: (nodeId: string) => void;
  enemyCount: number;
}

const getSceneNodes = (enemyCount: number): SceneNode[] => [
  {
    id: "main",
    name: "Main",
    type: "Node3D",
    icon: "📦",
    iconColor: "#478cbf",
    expanded: true,
    children: [
      {
        id: "player",
        name: "Player",
        type: "CharacterBody3D",
        icon: "🎮",
        iconColor: "#6aab73",
        expanded: true,
        children: [
          {
            id: "camera",
            name: "PlayerCamera",
            type: "Camera3D",
            icon: "📷",
            iconColor: "#e5c07b",
          },
          {
            id: "collision",
            name: "CollisionShape3D",
            type: "CollisionShape3D",
            icon: "⬡",
            iconColor: "#61afef",
          },
        ],
      },
      {
        id: "world",
        name: "World",
        type: "Node3D",
        icon: "🌍",
        iconColor: "#98c379",
        expanded: true,
        children: [
          {
            id: "floor",
            name: "Floor",
            type: "StaticBody3D",
            icon: "▢",
            iconColor: "#8888aa",
          },
          {
            id: "obstacles",
            name: "Obstacles",
            type: "Node3D",
            icon: "📁",
            iconColor: "#e5c07b",
          },
        ],
      },
      {
        id: "lighting",
        name: "DirectionalLight3D",
        type: "DirectionalLight3D",
        icon: "💡",
        iconColor: "#e5c07b",
      },
      {
        id: "environment",
        name: "WorldEnvironment",
        type: "WorldEnvironment",
        icon: "🌤",
        iconColor: "#61afef",
      },
      {
        id: "spawner",
        name: "EnemySpawner",
        type: "Node3D",
        icon: "👾",
        iconColor: "#e06c75",
        expanded: true,
        children: Array.from({ length: Math.min(enemyCount, 5) }, (_, i) => ({
          id: `enemy_${i}`,
          name: `Enemy_${i}`,
          type: "CharacterBody3D",
          icon: "👹",
          iconColor: "#e06c75",
        })),
      },
    ],
  },
  {
    id: "gamemanager",
    name: "GameManager",
    type: "Node (Autoload)",
    icon: "📊",
    iconColor: "#c678dd",
  },
];

function TreeNode({
  node,
  depth,
  selectedNode,
  onSelectNode,
  expandedNodes,
  toggleExpanded,
}: {
  node: SceneNode;
  depth: number;
  selectedNode: string | null;
  onSelectNode: (id: string) => void;
  expandedNodes: Set<string>;
  toggleExpanded: (id: string) => void;
}) {
  const hasChildren = node.children && node.children.length > 0;
  const isExpanded = expandedNodes.has(node.id);
  const isSelected = selectedNode === node.id;

  return (
    <div>
      <div
        className={`scene-tree-node ${isSelected ? "selected" : ""}`}
        style={{ paddingLeft: `${depth * 16 + 4}px` }}
        onClick={() => onSelectNode(node.id)}
      >
        {hasChildren ? (
          <button
            className="godot-btn-icon p-0 mr-1"
            onClick={(e) => {
              e.stopPropagation();
              toggleExpanded(node.id);
            }}
          >
            {isExpanded ? <ChevronDown /> : <ChevronRight />}
          </button>
        ) : (
          <span className="w-4" />
        )}
        <span className="mr-1.5" style={{ color: node.iconColor }}>
          {node.icon}
        </span>
        <span className="text-[11px] truncate">{node.name}</span>
        <span className="ml-1.5 text-[9px] text-[var(--godot-text-muted)]">
          {node.type}
        </span>
      </div>
      {hasChildren && isExpanded && (
        <div>
          {node.children!.map((child) => (
            <TreeNode
              key={child.id}
              node={child}
              depth={depth + 1}
              selectedNode={selectedNode}
              onSelectNode={onSelectNode}
              expandedNodes={expandedNodes}
              toggleExpanded={toggleExpanded}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export function SceneTree({ selectedNode, onSelectNode, enemyCount }: SceneTreeProps) {
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(
    new Set(["main", "player", "world", "spawner"])
  );

  const toggleExpanded = (id: string) => {
    setExpandedNodes((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const nodes = getSceneNodes(enemyCount);

  return (
    <div className="godot-panel h-full flex flex-col">
      <div className="godot-panel-header">
        <span>📑</span>
        <span>Scene</span>
      </div>
      <div className="flex-1 overflow-auto py-1">
        {nodes.map((node) => (
          <TreeNode
            key={node.id}
            node={node}
            depth={0}
            selectedNode={selectedNode}
            onSelectNode={onSelectNode}
            expandedNodes={expandedNodes}
            toggleExpanded={toggleExpanded}
          />
        ))}
      </div>
    </div>
  );
}
