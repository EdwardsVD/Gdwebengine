import { useEffect, useRef, useState, useCallback } from "react";
import type { GameState } from "@/types/godot";

interface LogEntry {
  id: number;
  timestamp: string;
  message: string;
  type: "info" | "warning" | "error" | "success" | "event";
}

interface OutputLogProps {
  gameState: GameState;
}

let logIdCounter = 0;

export function OutputLog({ gameState }: OutputLogProps) {
  const [logs, setLogs] = useState<LogEntry[]>([
    {
      id: logIdCounter++,
      timestamp: new Date().toLocaleTimeString(),
      message: "[Godot] Scene initialized",
      type: "info",
    },
    {
      id: logIdCounter++,
      timestamp: new Date().toLocaleTimeString(),
      message: "[GameManager] Initialized — Difficulty: 1",
      type: "success",
    },
  ]);
  const [activeTab, setActiveTab] = useState<"output" | "debugger">("output");
  const scrollRef = useRef<HTMLDivElement>(null);
  const prevStateRef = useRef(gameState);

  const addLog = useCallback((message: string, type: LogEntry["type"]) => {
    setLogs((prev) => [
      ...prev.slice(-100),
      {
        id: logIdCounter++,
        timestamp: new Date().toLocaleTimeString(),
        message,
        type,
      },
    ]);
  }, []);

  useEffect(() => {
    const prev = prevStateRef.current;

    if (gameState.score !== prev.score && gameState.score > prev.score) {
      addLog(`[Score] +${gameState.score - prev.score} points (combo x${gameState.combo})`, "event");
    }

    if (gameState.health !== prev.health && gameState.health < prev.health) {
      addLog(`[Player] Took ${prev.health - gameState.health} damage — HP: ${gameState.health}/${gameState.maxHealth}`, "warning");
    }

    if (gameState.enemyCount !== prev.enemyCount) {
      if (gameState.enemyCount > prev.enemyCount) {
        addLog(`[Spawner] Enemy spawned (${gameState.enemyCount}/${gameState.maxEnemies})`, "info");
      } else {
        addLog(`[Combat] Enemy killed! Total: ${gameState.enemiesKilled}`, "success");
      }
    }

    if (gameState.isPaused !== prev.isPaused) {
      addLog(gameState.isPaused ? "[Game] Paused" : "[Game] Resumed", "info");
    }

    if (!gameState.isRunning && prev.isRunning) {
      addLog(`[Game] Game Over — Score: ${gameState.score}`, "error");
    }

    if (gameState.difficulty !== prev.difficulty) {
      addLog(`[Settings] Difficulty changed to ${gameState.difficulty}`, "info");
    }

    prevStateRef.current = gameState;
  }, [gameState, addLog]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  const clearLogs = () => {
    setLogs([]);
    addLog("[Output] Cleared", "info");
  };

  return (
    <div className="godot-panel h-full flex flex-col">
      <div className="godot-tabs">
        <div
          className={`godot-tab ${activeTab === "output" ? "active" : ""}`}
          onClick={() => setActiveTab("output")}
        >
          Output
        </div>
        <div
          className={`godot-tab ${activeTab === "debugger" ? "active" : ""}`}
          onClick={() => setActiveTab("debugger")}
        >
          Debugger
        </div>
        <div className="godot-tab">Audio</div>
        <div className="godot-tab">Animation</div>
        <div className="flex-1" />
        <button
          className="godot-btn-icon mr-2"
          onClick={clearLogs}
          title="Clear Output"
        >
          <span>🗑</span>
        </button>
      </div>
      <div ref={scrollRef} className="flex-1 overflow-auto output-log">
        {activeTab === "output" ? (
          logs.map((log) => (
            <div key={log.id} className={`output-line ${log.type}`}>
              <span className="text-[var(--godot-text-muted)] mr-2">
                {log.timestamp}
              </span>
              {log.message}
            </div>
          ))
        ) : (
          <div className="p-4 text-[var(--godot-text-dim)] text-center">
            <div className="text-2xl mb-2">🐛</div>
            <div>Debugger connected</div>
            <div className="text-[10px] mt-1">
              FPS: {gameState.fps} | Enemies: {gameState.enemyCount}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
