interface MinimapProps {
  playerPosition: { x: number; y: number; z: number };
  enemyCount: number;
}

export function Minimap({ playerPosition, enemyCount }: MinimapProps) {
  const mapSize = 80;
  const scale = 2;
  
  // Normalize position to map coordinates
  const px = ((playerPosition.x / scale) + mapSize / 2) % mapSize;
  const pz = ((playerPosition.z / scale) + mapSize / 2) % mapSize;

  // Generate stable enemy positions
  const enemies = Array.from({ length: Math.min(enemyCount, 6) }, (_, i) => ({
    x: ((Math.sin(i * 137.5) * 0.5 + 0.5) * mapSize * 0.7) + mapSize * 0.15,
    y: ((Math.cos(i * 137.5) * 0.5 + 0.5) * mapSize * 0.7) + mapSize * 0.15,
  }));

  return (
    <div className="minimap-container w-20 h-20">
      {/* Grid */}
      <div className="minimap-grid" />
      
      {/* World bounds */}
      <div 
        className="absolute border border-white/30"
        style={{
          left: "10%",
          top: "10%",
          width: "80%",
          height: "80%",
        }}
      />

      {/* Enemies */}
      {enemies.map((enemy, i) => (
        <div
          key={i}
          className="absolute w-1.5 h-1.5 rounded-full bg-[var(--godot-error)]"
          style={{
            left: `${(enemy.x / mapSize) * 100}%`,
            top: `${(enemy.y / mapSize) * 100}%`,
            transform: "translate(-50%, -50%)",
          }}
        />
      ))}

      {/* Player - cyan diamond */}
      <div
        className="absolute transition-all duration-200"
        style={{
          left: `${(px / mapSize) * 100}%`,
          top: `${(pz / mapSize) * 100}%`,
          transform: "translate(-50%, -50%) rotate(45deg)",
        }}
      >
        <div className="w-2 h-2 bg-[var(--godot-accent)] border border-white/50" />
      </div>

      {/* Label */}
      <div className="absolute bottom-0.5 right-1 text-[8px] text-[var(--godot-text-muted)]">
        2D
      </div>
    </div>
  );
}
