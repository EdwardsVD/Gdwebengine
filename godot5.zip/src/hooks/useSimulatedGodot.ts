import { useCallback, useEffect, useRef, useState } from "react";
import type { GameState } from "@/types/godot";
import { initialGameState } from "@/types/godot";

/**
 * Simulates Godot game state when no actual Godot build is present.
 * This allows the React UI overlay to be developed and tested independently.
 * Remove this hook and use useGodot() when connecting to real Godot build.
 */
export function useSimulatedGodot() {
  const [gameState, setGameState] = useState<GameState>({
    ...initialGameState,
    isReady: true,
    isRunning: true,
    health: 100,
    maxHealth: 100,
    fps: 60,
    difficulty: 1,
  });

  const animationRef = useRef<number>(0);
  const timeRef = useRef(0);

  // Simulate game loop
  useEffect(() => {
    if (!gameState.isRunning || gameState.isPaused) return;

    let lastTime = performance.now();

    const loop = (now: number) => {
      const dt = (now - lastTime) / 1000;
      lastTime = now;
      timeRef.current += dt;

      setGameState((prev) => {
        if (!prev.isRunning || prev.isPaused) return prev;

        const t = timeRef.current;

        // Simulate player movement (circular path)
        const playerX = Math.sin(t * 0.5) * 15;
        const playerZ = Math.cos(t * 0.5) * 15;

        // Simulate FPS fluctuation
        const fps = Math.round(58 + Math.sin(t * 2) * 4);

        // Auto score increment
        const scoreInc = prev.difficulty * 10;

        // Periodic damage from enemies
        const damage =
          prev.enemyCount > 0 && Math.random() < 0.005 * prev.difficulty
            ? prev.difficulty * 2
            : 0;

        const newHealth = Math.max(0, prev.health - damage);

        // Check game over
        if (newHealth <= 0) {
          return {
            ...prev,
            health: 0,
            isRunning: false,
            survivalTime: t,
          };
        }

        return {
          ...prev,
          score: prev.score + Math.round(scoreInc * dt),
          playerPosition: { x: playerX, y: 1.0, z: playerZ },
          fps,
          health: newHealth,
          combo: Math.min(prev.combo + (Math.random() < 0.01 ? 1 : 0), 15),
          survivalTime: t,
        };
      });

      animationRef.current = requestAnimationFrame(loop);
    };

    animationRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animationRef.current);
  }, [gameState.isRunning, gameState.isPaused]);

  const spawnEnemy = useCallback(
    (type: "basic" | "fast" | "tank" = "basic", count = 1) => {
      setGameState((prev) => ({
        ...prev,
        enemyCount: Math.min(prev.enemyCount + count, prev.maxEnemies),
      }));

      // Auto-kill enemies after some time
      setTimeout(() => {
        setGameState((prev) => ({
          ...prev,
          enemyCount: Math.max(0, prev.enemyCount - 1),
          enemiesKilled: prev.enemiesKilled + 1,
          score: prev.score + (type === "tank" ? 500 : type === "fast" ? 200 : 100),
          combo: prev.combo + 1,
        }));
      }, 3000 + Math.random() * 5000);
    },
    []
  );

  const pauseGame = useCallback(() => {
    setGameState((prev) => ({ ...prev, isPaused: true }));
  }, []);

  const resumeGame = useCallback(() => {
    setGameState((prev) => ({ ...prev, isPaused: false }));
  }, []);

  const resetGame = useCallback(() => {
    timeRef.current = 0;
    setGameState({
      ...initialGameState,
      isReady: true,
      isRunning: true,
      health: 100,
      maxHealth: 100,
      fps: 60,
      difficulty: 1,
    });
  }, []);

  const setDifficulty = useCallback((level: number) => {
    setGameState((prev) => ({ ...prev, difficulty: level }));
  }, []);

  // Auto-spawn enemies periodically
  useEffect(() => {
    if (!gameState.isRunning || gameState.isPaused) return;

    const interval = setInterval(() => {
      if (gameState.enemyCount < 5) {
        spawnEnemy("basic");
      }
    }, 8000 / gameState.difficulty);

    return () => clearInterval(interval);
  }, [gameState.isRunning, gameState.isPaused, gameState.difficulty, gameState.enemyCount, spawnEnemy]);

  return {
    gameState,
    spawnEnemy,
    pauseGame,
    resumeGame,
    resetGame,
    setDifficulty,
    isSimulated: true,
  };
}
