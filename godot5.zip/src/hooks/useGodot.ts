import { useCallback, useEffect, useReducer, useRef } from "react";
import type {
  GameState,
  GodotMessage,
  GodotPlayerRef,
  GodotToReactEvent,
  ReactToGodotPayload,
} from "@/types/godot";
import { initialGameState } from "@/types/godot";

// --- Reducer for game state ---

type GameAction =
  | { type: "SCORE_UPDATE"; data: { score: number; combo: number } }
  | { type: "HEALTH_UPDATE"; data: { health: number; maxHealth: number } }
  | { type: "PLAYER_POSITION"; data: { x: number; y: number; z: number } }
  | { type: "ENEMY_COUNT"; data: { count: number; maxEnemies: number } }
  | { type: "FPS_UPDATE"; data: { fps: number } }
  | { type: "GAME_READY" }
  | { type: "GAME_OVER"; data: { finalScore: number; enemiesKilled: number; survivalTime: number } }
  | { type: "ENEMY_KILLED"; data: { points: number } }
  | { type: "DAMAGE_TAKEN"; data: { remainingHealth: number } }
  | { type: "SET_PAUSED"; paused: boolean }
  | { type: "SET_RUNNING"; running: boolean }
  | { type: "SET_DIFFICULTY"; level: number }
  | { type: "RESET" };

function gameReducer(state: GameState, action: GameAction): GameState {
  switch (action.type) {
    case "SCORE_UPDATE":
      return { ...state, score: action.data.score, combo: action.data.combo };
    case "HEALTH_UPDATE":
      return { ...state, health: action.data.health, maxHealth: action.data.maxHealth };
    case "PLAYER_POSITION":
      return { ...state, playerPosition: action.data };
    case "ENEMY_COUNT":
      return {
        ...state,
        enemyCount: action.data.count,
        maxEnemies: action.data.maxEnemies,
      };
    case "FPS_UPDATE":
      return { ...state, fps: action.data.fps };
    case "GAME_READY":
      return { ...state, isReady: true, isRunning: true };
    case "GAME_OVER":
      return {
        ...state,
        isRunning: false,
        enemiesKilled: action.data.enemiesKilled,
        survivalTime: action.data.survivalTime,
      };
    case "ENEMY_KILLED":
      return { ...state, enemiesKilled: state.enemiesKilled + 1 };
    case "DAMAGE_TAKEN":
      return { ...state, health: action.data.remainingHealth };
    case "SET_PAUSED":
      return { ...state, isPaused: action.paused };
    case "SET_RUNNING":
      return { ...state, isRunning: action.running };
    case "SET_DIFFICULTY":
      return { ...state, difficulty: action.level };
    case "RESET":
      return { ...initialGameState, isReady: state.isReady };
    default:
      return state;
  }
}

// --- Event listener map type ---

type EventCallback = (data: Record<string, unknown>) => void;

// --- Hook ---

export function useGodot() {
  const [gameState, dispatch] = useReducer(gameReducer, initialGameState);
  const godotRef = useRef<GodotPlayerRef>(null);
  const listenersRef = useRef<Map<GodotToReactEvent, Set<EventCallback>>>(new Map());
  
  // Stable dispatch ref to avoid stale closures in useEffect
  const dispatchRef = useRef(dispatch);
  useEffect(() => {
    dispatchRef.current = dispatch;
  });

  // Listen for postMessage events from Godot iframe
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      // Validate message is from Godot
      const msg = event.data as GodotMessage;
      if (!msg || msg.source !== "godot") return;
      
      // Use ref to avoid stale closure
      const stableDispatch = dispatchRef.current;
      
      // Dispatch to reducer
      switch (msg.event) {
        case "score_update":
          stableDispatch({
            type: "SCORE_UPDATE",
            data: msg.data as { score: number; combo: number },
          });
          break;
        case "health_update":
          stableDispatch({
            type: "HEALTH_UPDATE",
            data: msg.data as { health: number; maxHealth: number },
          });
          break;
        case "player_position":
          stableDispatch({
            type: "PLAYER_POSITION",
            data: msg.data as { x: number; y: number; z: number },
          });
          break;
        case "enemy_count":
          stableDispatch({
            type: "ENEMY_COUNT",
            data: msg.data as { count: number; maxEnemies: number },
          });
          break;
        case "fps_update":
          stableDispatch({
            type: "FPS_UPDATE",
            data: msg.data as { fps: number },
          });
          break;
        case "game_ready":
          stableDispatch({ type: "GAME_READY" });
          break;
        case "game_over":
          stableDispatch({
            type: "GAME_OVER",
            data: msg.data as {
              finalScore: number;
              enemiesKilled: number;
              survivalTime: number;
            },
          });
          break;
        case "enemy_killed":
          stableDispatch({
            type: "ENEMY_KILLED",
            data: msg.data as { points: number },
          });
          break;
        case "damage_taken":
          stableDispatch({
            type: "DAMAGE_TAKEN",
            data: msg.data as { remainingHealth: number },
          });
          break;
      }

      // Notify external listeners
      const callbacks = listenersRef.current.get(msg.event);
      if (callbacks) {
        callbacks.forEach((cb) => cb(msg.data));
      }
    };

    window.addEventListener("message", handleMessage);
    return () => window.removeEventListener("message", handleMessage);
  }, []); // Empty deps - handler uses refs

  // Send command to Godot
  const sendToGodot = useCallback(
    <T extends ReactToGodotPayload>(action: T["action"], data?: T["data"]) => {
      if (godotRef.current) {
        godotRef.current.sendToGodot(action, data);
      }
    },
    []
  );

  // Subscribe to specific Godot events
  const onGodotEvent = useCallback(
    (event: GodotToReactEvent, callback: EventCallback) => {
      if (!listenersRef.current.has(event)) {
        listenersRef.current.set(event, new Set());
      }
      listenersRef.current.get(event)!.add(callback);

      // Return unsubscribe function
      return () => {
        listenersRef.current.get(event)?.delete(callback);
      };
    },
    []
  );

  // Convenience actions
  const spawnEnemy = useCallback(
    (type: "basic" | "fast" | "tank" = "basic", count = 1) => {
      sendToGodot("spawn_enemy", { type, count });
    },
    [sendToGodot]
  );

  const pauseGame = useCallback(() => {
    sendToGodot("pause");
    dispatch({ type: "SET_PAUSED", paused: true });
  }, [sendToGodot]);

  const resumeGame = useCallback(() => {
    sendToGodot("resume");
    dispatch({ type: "SET_PAUSED", paused: false });
  }, [sendToGodot]);

  const resetGame = useCallback(() => {
    sendToGodot("reset_game");
    dispatch({ type: "RESET" });
  }, [sendToGodot]);

  const setDifficulty = useCallback(
    (level: number) => {
      sendToGodot("update_difficulty", { level });
      dispatch({ type: "SET_DIFFICULTY", level });
    },
    [sendToGodot]
  );

  return {
    gameState,
    godotRef,
    sendToGodot,
    onGodotEvent,
    spawnEnemy,
    pauseGame,
    resumeGame,
    resetGame,
    setDifficulty,
  };
}
