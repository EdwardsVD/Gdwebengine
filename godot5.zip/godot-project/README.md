# Godot 4 Arena3D — 3D Game Project

## Scene Structure (Main.tscn)

Create this scene hierarchy manually in the Godot Editor:

```
Main (Node3D)                          → scripts/Main.gd
├── WorldEnvironment                    → (configured by LightingSetup.gd or manually)
│   └── environment: Environment
│       ├── Background: SKY
│       ├── Sky → ProceduralSkyMaterial (dark night sky)
│       ├── SSAO: enabled, radius=2.0, intensity=1.5
│       ├── SSIL: enabled
│       ├── Glow: enabled, intensity=0.3
│       ├── Tonemap: ACES, exposure=1.0
│       ├── Fog: enabled, density=0.005
│       └── Volumetric Fog: enabled, density=0.01
│
├── DirectionalLight3D (SunLight)       → rotation=(-45°, 30°, 0°)
│   ├── light_color = Color(0.9, 0.85, 0.75)
│   ├── light_energy = 0.8
│   ├── shadow_enabled = true
│   ├── shadow_bias = 0.03
│   └── directional_shadow_mode = PARALLEL_4_SPLITS
│
├── DirectionalLight3D (FillLight)      → rotation=(-30°, -150°, 0°)
│   ├── light_color = Color(0.3, 0.35, 0.5)
│   ├── light_energy = 0.2
│   └── shadow_enabled = false
│
├── World (Node3D)                      → scripts/World.gd
│   ├── (Generated at runtime: Floor, Walls, Obstacles)
│   └── All use StaticBody3D + MeshInstance3D + CollisionShape3D
│
├── Player (CharacterBody3D)            → scripts/Player.gd
│   ├── CollisionShape3D
│   │   └── CapsuleShape3D (radius=0.4, height=1.8)
│   ├── PlayerModel (MeshInstance3D)
│   │   └── CapsuleMesh (radius=0.4, height=1.8)
│   │   └── StandardMaterial3D (albedo=cyan)
│   └── CameraMount (Node3D)           → scripts/PlayerCamera.gd
│       └── Camera3D
│           ├── current = true
│           ├── fov = 75
│           ├── near = 0.05
│           └── far = 500.0
│
└── EnemySpawner (Node3D)
    └── (Enemies added at runtime by GameManager)
```

## Setup Steps

### 1. Create Godot 4 Project
- Open Godot 4.2+
- Create new project named "Arena3D"
- Set renderer to **Forward+** (required for 3D features)

### 2. Copy Scripts
Copy all `.gd` files from `scripts/` into your project's `res://scripts/`

### 3. Create Main Scene
1. Create `Main.tscn` with the node hierarchy above
2. Attach `Main.gd` to the root Node3D
3. Create child nodes and attach respective scripts

### 4. Configure Autoload
- Go to **Project → Project Settings → Autoload**
- Add `res://scripts/GameManager.gd` as `GameManager` (singleton)

### 5. Configure Input Map
- Go to **Project → Project Settings → Input Map**
- Add actions: `move_forward` (W), `move_backward` (S), `move_left` (A), `move_right` (D), `jump` (Space)

### 6. Configure Physics Layers
- Layer 1: "world" (floor, walls, obstacles)
- Layer 2: "player"
- Layer 3: "enemy"

### 7. Export for Web
1. Install Web export template: **Editor → Manage Export Templates**
2. Go to **Project → Export → Add → Web**
3. Enable **Thread Support** (required for good performance)
4. Enable **VRAM Texture Compression → For Desktop**
5. Export to `../public/godot-build/index.html`

### 8. CORS Headers
The Vite dev server is pre-configured with required headers:
- `Cross-Origin-Opener-Policy: same-origin`
- `Cross-Origin-Embedder-Policy: require-corp`

These are required for `SharedArrayBuffer` which Godot 4 threading uses.

## React ↔ Godot Communication

### React → Godot (postMessage)
```javascript
iframe.contentWindow.postMessage({
  source: "react",
  action: "spawn_enemy",
  data: { type: "basic", count: 1 }
}, "*");
```

### Godot → React (JavaScriptBridge)
```gdscript
JavaScriptBridge.eval("""
  window.parent.postMessage({
    source: 'godot',
    event: 'score_update',
    data: { score: 1000, combo: 5 }
  }, '*');
""")
```

### Available Commands (React → Godot)
| Action | Data | Description |
|--------|------|-------------|
| `spawn_enemy` | `{ type, count }` | Spawn enemies |
| `pause` | - | Pause game |
| `resume` | - | Resume game |
| `reset_game` | - | Reset all state |
| `update_difficulty` | `{ level }` | Set difficulty 1-10 |
| `change_scene` | `{ scene }` | Load new scene |

### Available Events (Godot → React)
| Event | Data | Description |
|-------|------|-------------|
| `game_ready` | - | Engine initialized |
| `score_update` | `{ score, combo }` | Score changed |
| `health_update` | `{ health, maxHealth }` | Health changed |
| `player_position` | `{ x, y, z }` | Player moved |
| `enemy_count` | `{ count, maxEnemies }` | Enemy count changed |
| `fps_update` | `{ fps }` | FPS telemetry |
| `game_over` | `{ finalScore, enemiesKilled, survivalTime }` | Player died |
| `enemy_killed` | `{ points, enemyType, position }` | Enemy killed |
| `damage_taken` | `{ damage, source, remainingHealth }` | Player damaged |
