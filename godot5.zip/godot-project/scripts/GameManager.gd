## GameManager.gd — Autoload Singleton
## Autoloaded in project.godot: GameManager="*res://scripts/GameManager.gd"

extends Node

## Game state
var score: int = 0
var combo: int = 0
var difficulty: int = 1
var enemies_killed: int = 0
var is_paused: bool = false
var is_running: bool = false
var game_start_time: float = 0.0
var current_health: float = 100.0
var max_health: float = 100.0

## References
var player: CharacterBody3D = null
var world: Node3D = null
var enemy_spawner: Node3D = null

## Enemy tracking
var active_enemies: Array[CharacterBody3D] = []
var max_enemies: int = 20

## FPS tracking
var _fps_timer: float = 0.0
var _fps_send_interval: float = 0.5
var _combo_timer: float = 0.0

func initialize(p: CharacterBody3D, w: Node3D, spawner: Node3D) -> void:
	player = p
	world = w
	enemy_spawner = spawner
	is_running = true
	game_start_time = Time.get_ticks_msec() / 1000.0
	
	if player:
		current_health = player.max_health
		max_health = player.max_health
		if player.has_signal("player_died"):
			player.player_died.connect(_on_player_died)
	
	print("[GameManager] Initialized — Difficulty: %d" % difficulty)

func _process(delta: float) -> void:
	if not is_running or is_paused:
		return
	
	_fps_timer += delta
	if _fps_timer >= _fps_send_interval:
		_fps_timer = 0.0
		send_to_react("fps_update", {
			"fps": Engine.get_frames_per_second()
		})
	
	_update_combo(delta)

func _update_combo(delta: float) -> void:
	_combo_timer += delta
	if _combo_timer >= 5.0 and combo > 0:
		combo = max(0, combo - 1)
		_combo_timer = 0.0
		_send_score_update()

## --- React Communication ---

func send_to_react(event: String, data: Dictionary) -> void:
	if not OS.has_feature("web"):
		return
	
	var json_data = JSON.stringify(data)
	var js_code = """
	(function() {
		if (window.parent && window.parent !== window) {
			window.parent.postMessage({
				source: 'godot',
				event: '%s',
				data: %s
			}, '*');
		}
	})();
	""" % [event, json_data]
	
	JavaScriptBridge.eval(js_code)

## --- Game Control ---

func pause_game() -> void:
	is_paused = true
	get_tree().paused = true
	print("[GameManager] Game paused")

func resume_game() -> void:
	is_paused = false
	get_tree().paused = false
	print("[GameManager] Game resumed")

func reset_game() -> void:
	score = 0
	combo = 0
	enemies_killed = 0
	game_start_time = Time.get_ticks_msec() / 1000.0
	
	for enemy in active_enemies:
		if is_instance_valid(enemy):
			enemy.queue_free()
	active_enemies.clear()
	
	if player and player.has_method("reset"):
		player.reset()
		current_health = player.max_health
		max_health = player.max_health
	
	if world and world.has_method("regenerate"):
		world.regenerate()
	
	is_running = true
	is_paused = false
	get_tree().paused = false
	
	_send_score_update()
	send_to_react("health_update", {
		"health": current_health,
		"maxHealth": max_health
	})
	send_to_react("enemy_count", {
		"count": 0,
		"maxEnemies": max_enemies
	})
	
	print("[GameManager] Game reset")

func game_over() -> void:
	is_running = false
	var survival_time = (Time.get_ticks_msec() / 1000.0) - game_start_time
	
	send_to_react("game_over", {
		"finalScore": score,
		"enemiesKilled": enemies_killed,
		"survivalTime": survival_time
	})
	
	print("[GameManager] Game Over — Score: %d, Killed: %d" % [score, enemies_killed])

func set_difficulty(level: int) -> void:
	difficulty = clampi(level, 1, 10)
	
	for enemy in active_enemies:
		if is_instance_valid(enemy) and enemy.has_method("apply_difficulty"):
			enemy.apply_difficulty(difficulty)
	
	print("[GameManager] Difficulty: %d" % difficulty)

func change_scene(scene_name: String) -> void:
	print("[GameManager] Scene change: %s" % scene_name)

## --- Health Management ---

func on_player_damaged(damage: float, source: String, health: float, max_hp: float) -> void:
	## Called by Player.gd when damage is taken
	current_health = health
	max_health = max_hp
	
	send_to_react("health_update", {
		"health": current_health,
		"maxHealth": max_health
	})
	send_to_react("damage_taken", {
		"damage": damage,
		"source": source,
		"remainingHealth": current_health
	})
	
	print("[GameManager] Damage: %d from %s — HP: %d/%d" % [damage, source, current_health, max_health])

## --- Enemy Management ---

func spawn_enemy(type_name: String = "basic") -> void:
	if active_enemies.size() >= max_enemies:
		return
	
	if enemy_spawner == null:
		return
	
	var enemy = CharacterBody3D.new()
	var script = load("res://scripts/Enemy.gd")
	enemy.set_script(script)
	
	match type_name:
		"fast":
			enemy.enemy_type = 1
		"tank":
			enemy.enemy_type = 2
		_:
			enemy.enemy_type = 0
	
	var rng = RandomNumberGenerator.new()
	rng.randomize()
	var arena_half = 20.0
	var side = rng.randi() % 4
	var spawn_pos = Vector3.ZERO
	
	match side:
		0: spawn_pos = Vector3(rng.randf_range(-arena_half, arena_half), 1.0, arena_half)
		1: spawn_pos = Vector3(rng.randf_range(-arena_half, arena_half), 1.0, -arena_half)
		2: spawn_pos = Vector3(arena_half, 1.0, rng.randf_range(-arena_half, arena_half))
		3: spawn_pos = Vector3(-arena_half, 1.0, rng.randf_range(-arena_half, arena_half))
	
	enemy.position = spawn_pos
	enemy.name = "Enemy_%d" % (enemies_killed + active_enemies.size())
	enemy.enemy_died.connect(_on_enemy_died)
	enemy.apply_difficulty.call_deferred(difficulty)
	
	enemy_spawner.add_child(enemy)
	active_enemies.append(enemy)
	
	send_to_react("enemy_count", {
		"count": active_enemies.size(),
		"maxEnemies": max_enemies
	})

func _on_enemy_died(enemy: CharacterBody3D, points: int, enemy_type_name: String) -> void:
	enemies_killed += 1
	combo += 1
	_combo_timer = 0.0
	var actual_points = points * combo
	score += actual_points
	
	active_enemies.erase(enemy)
	
	_send_score_update()
	send_to_react("enemy_killed", {
		"points": actual_points,
		"enemyType": enemy_type_name,
		"position": {
			"x": enemy.global_position.x,
			"y": enemy.global_position.y,
			"z": enemy.global_position.z
		}
	})
	send_to_react("enemy_count", {
		"count": active_enemies.size(),
		"maxEnemies": max_enemies
	})

func _on_player_died() -> void:
	game_over()

func _send_score_update() -> void:
	send_to_react("score_update", {
		"score": score,
		"combo": combo
	})
