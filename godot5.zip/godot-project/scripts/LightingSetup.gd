## LightingSetup.gd — Scene lighting and environment configuration
## This script is NOT attached to any node. Instead, it documents
## the manual setup required in the Godot Editor for Main.tscn.
##
## Alternatively, attach this to Main node and call setup_lighting()
## to programmatically create the lighting.
##
## Lighting components in Main.tscn:
## ```
## Main (Node3D)
##   ├── WorldEnvironment
##   │   └── environment: Environment resource
##   │       ├── background_mode = SKY
##   │       ├── sky = Sky resource
##   │       │   └── sky_material = ProceduralSkyMaterial
##   │       │       ├── sky_top_color = Color(0.05, 0.05, 0.15)
##   │       │       ├── sky_horizon_color = Color(0.1, 0.12, 0.2)
##   │       │       ├── ground_bottom_color = Color(0.02, 0.02, 0.05)
##   │       │       └── ground_horizon_color = Color(0.08, 0.08, 0.12)
##   │       ├── ambient_light_source = SKY
##   │       ├── ambient_light_color = Color(0.15, 0.15, 0.25)
##   │       ├── ambient_light_energy = 0.3
##   │       ├── ssao_enabled = true
##   │       ├── ssao_radius = 2.0
##   │       ├── ssao_intensity = 1.5
##   │       ├── ssil_enabled = true
##   │       ├── glow_enabled = true
##   │       ├── glow_intensity = 0.3
##   │       ├── glow_bloom = 0.1
##   │       ├── tonemap_mode = ACES
##   │       └── tonemap_exposure = 1.0
##   │
##   └── DirectionalLight3D
##       ├── light_color = Color(0.9, 0.85, 0.75)
##       ├── light_energy = 0.8
##       ├── shadow_enabled = true
##       ├── shadow_bias = 0.03
##       ├── shadow_normal_bias = 2.0
##       ├── directional_shadow_mode = PARALLEL_4_SPLITS
##       ├── rotation = Vector3(-45°, 30°, 0°)
##       └── light_angular_distance = 1.0  (soft shadows)
## ```

extends Node3D

func setup_lighting() -> void:
	_create_world_environment()
	_create_directional_light()
	print("[LightingSetup] Lighting configured")

func _create_world_environment() -> void:
	var world_env = WorldEnvironment.new()
	world_env.name = "WorldEnvironment"
	
	var env = Environment.new()
	
	# Sky
	env.background_mode = Environment.BG_SKY
	var sky = Sky.new()
	var sky_material = ProceduralSkyMaterial.new()
	sky_material.sky_top_color = Color(0.05, 0.05, 0.15)
	sky_material.sky_horizon_color = Color(0.1, 0.12, 0.2)
	sky_material.ground_bottom_color = Color(0.02, 0.02, 0.05)
	sky_material.ground_horizon_color = Color(0.08, 0.08, 0.12)
	sky_material.sun_angle_max = 30.0
	sky_material.sun_curve = 0.1
	sky.sky_material = sky_material
	env.sky = sky
	
	# Ambient light
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_color = Color(0.15, 0.15, 0.25)
	env.ambient_light_energy = 0.3
	
	# SSAO (Screen Space Ambient Occlusion)
	env.ssao_enabled = true
	env.ssao_radius = 2.0
	env.ssao_intensity = 1.5
	
	# SSIL (Screen Space Indirect Lighting)
	env.ssil_enabled = true
	
	# Glow / Bloom
	env.glow_enabled = true
	env.glow_intensity = 0.3
	env.glow_bloom = 0.1
	env.glow_blend_mode = Environment.GLOW_BLEND_MODE_SOFTLIGHT
	
	# Tone mapping
	env.tonemap_mode = Environment.TONE_MAPPER_ACES
	env.tonemap_exposure = 1.0
	
	# Fog (atmospheric)
	env.fog_enabled = true
	env.fog_light_color = Color(0.05, 0.06, 0.1)
	env.fog_density = 0.005
	env.fog_sky_affect = 0.3
	
	# Volumetric fog (Forward+ only)
	env.volumetric_fog_enabled = true
	env.volumetric_fog_density = 0.01
	env.volumetric_fog_albedo = Color(0.1, 0.1, 0.15)
	env.volumetric_fog_emission = Color(0.02, 0.03, 0.05)
	
	world_env.environment = env
	add_child(world_env)

func _create_directional_light() -> void:
	var light = DirectionalLight3D.new()
	light.name = "SunLight"
	
	# Light properties
	light.light_color = Color(0.9, 0.85, 0.75)
	light.light_energy = 0.8
	light.light_angular_distance = 1.0  # Soft shadow edges
	
	# Shadow configuration
	light.shadow_enabled = true
	light.shadow_bias = 0.03
	light.shadow_normal_bias = 2.0
	light.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
	light.directional_shadow_max_distance = 100.0
	
	# Sun angle (45 degrees down, slightly rotated)
	light.rotation_degrees = Vector3(-45, 30, 0)
	
	add_child(light)
	
	# Add a secondary fill light (dimmer, from opposite direction)
	var fill_light = DirectionalLight3D.new()
	fill_light.name = "FillLight"
	fill_light.light_color = Color(0.3, 0.35, 0.5)
	fill_light.light_energy = 0.2
	fill_light.shadow_enabled = false
	fill_light.rotation_degrees = Vector3(-30, -150, 0)
	add_child(fill_light)
