## PlayerCamera.gd — First-person camera with mouse look
## Attached to CameraMount (Node3D, parent of Camera3D)

extends Node3D

## Camera settings
@export var mouse_sensitivity: float = 0.002
@export var vertical_clamp: float = 89.0
@export var smooth_speed: float = 20.0
@export var fov: float = 75.0

## Internal state
var _rotation_x: float = 0.0
var _rotation_y: float = 0.0
var _target_rotation_x: float = 0.0
var _target_rotation_y: float = 0.0

## Reference to the actual camera
@onready var camera: Camera3D = $Camera3D

func _ready() -> void:
	position = Vector3(0, 0.8, 0)
	
	if camera:
		camera.fov = fov
		camera.near = 0.05
		camera.far = 500.0
		camera.current = true
	
	print("[PlayerCamera] Camera initialized — FOV: %d" % fov)

func _input(event: InputEvent) -> void:
	# Handle Escape key for pointer lock
	if event is InputEventKey:
		if event.pressed and event.keycode == KEY_ESCAPE:
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	
	# Handle mouse click to recapture
	if event is InputEventMouseButton:
		if event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
			if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
				Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	
	# Handle mouse motion for looking
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		var motion := event as InputEventMouseMotion
		_target_rotation_y -= motion.relative.x * mouse_sensitivity
		_target_rotation_x -= motion.relative.y * mouse_sensitivity
		_target_rotation_x = clampf(
			_target_rotation_x,
			deg_to_rad(-vertical_clamp),
			deg_to_rad(vertical_clamp)
		)

func _process(delta: float) -> void:
	_apply_smooth_rotation(delta)

func _apply_smooth_rotation(delta: float) -> void:
	var t = clampf(smooth_speed * delta, 0.0, 1.0)
	
	_rotation_x = lerpf(_rotation_x, _target_rotation_x, t)
	_rotation_y = lerpf(_rotation_y, _target_rotation_y, t)
	
	rotation.y = _rotation_y
	
	if camera:
		camera.rotation.x = _rotation_x

## --- Public API ---

func set_sensitivity(value: float) -> void:
	mouse_sensitivity = clampf(value, 0.0001, 0.01)

func reset_rotation() -> void:
	_rotation_x = 0.0
	_rotation_y = 0.0
	_target_rotation_x = 0.0
	_target_rotation_y = 0.0
	rotation = Vector3.ZERO
	if camera:
		camera.rotation = Vector3.ZERO

func look_at_position(target: Vector3) -> void:
	var dir = (target - global_position).normalized()
	_target_rotation_y = atan2(-dir.x, -dir.z)
	_target_rotation_x = asin(dir.y)
	_target_rotation_x = clampf(
		_target_rotation_x,
		deg_to_rad(-vertical_clamp),
		deg_to_rad(vertical_clamp)
	)
