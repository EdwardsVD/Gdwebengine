## Player.gd — CharacterBody3D player controller

extends CharacterBody3D

## Movement parameters
@export var move_speed: float = 7.0
@export var sprint_speed: float = 12.0
@export var jump_velocity: float = 6.0
@export var acceleration: float = 15.0
@export var deceleration: float = 10.0
@export var air_control: float = 0.3

## Health
@export var max_health: float = 100.0
var current_health: float = 100.0

## Internal state
var _gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")
var _is_sprinting: bool = false
var _last_position_sent: Vector3 = Vector3.ZERO
var _position_send_timer: float = 0.0

## Signals
signal health_changed(current: float, max_val: float)
signal player_died

## References
@onready var camera_mount: Node3D = $CameraMount

func _ready() -> void:
	current_health = max_health
	collision_layer = 2
	collision_mask = 1 | 4
	add_to_group("player")
	print("[Player] Ready — HP: %d/%d" % [current_health, max_health])

func _physics_process(delta: float) -> void:
	_apply_gravity(delta)
	_handle_jump()
	_handle_movement(delta)
	move_and_slide()
	_send_position_update(delta)

func _apply_gravity(delta: float) -> void:
	if not is_on_floor():
		velocity.y -= _gravity * delta

func _handle_jump() -> void:
	# Support both custom "jump" action and "ui_accept" (Space/Enter)
	var jump_pressed = false
	
	if InputMap.has_action("jump"):
		jump_pressed = Input.is_action_just_pressed("jump")
	
	# Fallback to ui_accept
	if not jump_pressed:
		jump_pressed = Input.is_action_just_pressed("ui_accept")
	
	# Also support direct spacebar check
	if not jump_pressed:
		jump_pressed = Input.is_key_pressed(KEY_SPACE) and is_on_floor()
	
	if jump_pressed and is_on_floor():
		velocity.y = jump_velocity

func _handle_movement(delta: float) -> void:
	## Get input direction
	var input_dir := Vector2.ZERO
	
	# Custom actions or direct key checks
	if InputMap.has_action("move_left") and InputMap.has_action("move_right"):
		input_dir.x = Input.get_axis("move_left", "move_right")
	else:
		input_dir.x = float(Input.is_key_pressed(KEY_D)) - float(Input.is_key_pressed(KEY_A))
	
	if InputMap.has_action("move_forward") and InputMap.has_action("move_backward"):
		input_dir.y = Input.get_axis("move_forward", "move_backward")
	else:
		input_dir.y = float(Input.is_key_pressed(KEY_S)) - float(Input.is_key_pressed(KEY_W))
	
	input_dir = input_dir.normalized()
	
	## Camera-relative movement direction
	var direction := Vector3.ZERO
	if camera_mount and input_dir.length() > 0.01:
		# Get camera's basis for direction transformation
		var cam_basis = camera_mount.global_transform.basis
		# Transform input to camera-relative direction
		direction = (cam_basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
		# Flatten to horizontal plane
		direction.y = 0
		if direction.length() > 0.01:
			direction = direction.normalized()
	
	## Sprint
	_is_sprinting = Input.is_key_pressed(KEY_SHIFT)
	var speed = sprint_speed if _is_sprinting else move_speed
	
	## Smooth acceleration
	var accel = acceleration if direction.length() > 0 else deceleration
	if not is_on_floor():
		accel *= air_control
	
	var target_velocity = direction * speed
	velocity.x = move_toward(velocity.x, target_velocity.x, accel * delta)
	velocity.z = move_toward(velocity.z, target_velocity.z, accel * delta)

func _send_position_update(delta: float) -> void:
	_position_send_timer += delta
	if _position_send_timer >= 0.1:
		_position_send_timer = 0.0
		var pos = global_position
		if pos.distance_to(_last_position_sent) > 0.01:
			_last_position_sent = pos
			GameManager.send_to_react("player_position", {
				"x": snappedf(pos.x, 0.1),
				"y": snappedf(pos.y, 0.1),
				"z": snappedf(pos.z, 0.1)
			})

## --- Public API ---

func take_damage(amount: float, source: String = "unknown") -> void:
	current_health = clampf(current_health - amount, 0.0, max_health)
	health_changed.emit(current_health, max_health)
	
	# Notify GameManager (which sends to React)
	GameManager.on_player_damaged(amount, source, current_health, max_health)
	
	if current_health <= 0:
		_die()

func heal(amount: float) -> void:
	current_health = clampf(current_health + amount, 0.0, max_health)
	health_changed.emit(current_health, max_health)
	GameManager.send_to_react("health_update", {
		"health": current_health,
		"maxHealth": max_health
	})

func reset() -> void:
	current_health = max_health
	global_position = Vector3(0, 1, 0)
	velocity = Vector3.ZERO
	health_changed.emit(current_health, max_health)
	if camera_mount and camera_mount.has_method("reset_rotation"):
		camera_mount.reset_rotation()

func _die() -> void:
	player_died.emit()
	GameManager.game_over()
	print("[Player] Player died!")
