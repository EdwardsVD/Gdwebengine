## Main.gd — Entry point scene script
## Attached to the root Node3D of Main.tscn

extends Node3D

@onready var world: Node3D = $World
@onready var player: CharacterBody3D = $Player
@onready var enemy_spawner: Node3D = $EnemySpawner

# JavaScript callback reference (prevents GC)
var _js_message_callback: JavaScriptObject = null
var _js_window: JavaScriptObject = null

func _ready() -> void:
	print("[Main] Scene initialized")
	
	# Setup JavaScript bridge for web builds
	if OS.has_feature("web"):
		_setup_js_bridge()
	
	# Initialize GameManager
	GameManager.initialize(player, world, enemy_spawner)
	
	# Notify React that game is ready
	GameManager.send_to_react("game_ready", {})
	
	# Capture mouse for FPS controls
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _setup_js_bridge() -> void:
	## Wire postMessage listener using JavaScriptBridge
	_js_window = JavaScriptBridge.get_interface("window")
	if _js_window:
		_js_message_callback = JavaScriptBridge.create_callback(_on_react_message)
		_js_window.addEventListener("message", _js_message_callback)
		print("[Main] JavaScript bridge connected")
	else:
		push_warning("[Main] Could not get window interface")

func _on_react_message(args: Array) -> void:
	## Callback from JavaScript postMessage
	if args.size() == 0:
		return
	
	var event = args[0]
	if event == null:
		return
	
	# Check source
	var data = event.data
	if data == null:
		return
	
	var source = ""
	if "source" in data:
		source = str(data.source)
	
	if source != "react":
		return
	
	# Extract action and payload
	var action = ""
	if "action" in data:
		action = str(data.action)
	
	var payload = {}
	if "data" in data:
		var raw = data.data
		if raw != null:
			# Convert JS object to dict
			if "type" in raw:
				payload["type"] = str(raw.type)
			if "count" in raw:
				payload["count"] = int(raw.count)
			if "level" in raw:
				payload["level"] = int(raw.level)
			if "scene" in raw:
				payload["scene"] = str(raw.scene)
	
	_handle_react_command(action, payload)

func _handle_react_command(action: String, data: Dictionary) -> void:
	## Route React commands to appropriate systems
	print("[Main] React command: %s" % action)
	
	match action:
		"spawn_enemy":
			var enemy_type = data.get("type", "basic")
			var count = data.get("count", 1)
			for i in range(count):
				GameManager.spawn_enemy(str(enemy_type))
		
		"change_scene":
			var scene_name = data.get("scene", "")
			if scene_name != "":
				GameManager.change_scene(str(scene_name))
		
		"pause":
			GameManager.pause_game()
		
		"resume":
			GameManager.resume_game()
		
		"reset_game":
			GameManager.reset_game()
		
		"update_difficulty":
			var level = data.get("level", 1)
			GameManager.set_difficulty(int(level))
		
		_:
			print("[Main] Unknown action: %s" % action)

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey:
		if event.pressed and event.keycode == KEY_ESCAPE:
			if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
				Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
			else:
				Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _exit_tree() -> void:
	# Cleanup JS listener
	if OS.has_feature("web") and _js_window and _js_message_callback:
		_js_window.removeEventListener("message", _js_message_callback)
