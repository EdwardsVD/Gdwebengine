## World.gd — Procedural 3D environment generator

extends Node3D

@export var arena_size: float = 50.0
@export var wall_height: float = 5.0
@export var wall_thickness: float = 0.5
@export var obstacle_count: int = 15

## Materials
var floor_material: StandardMaterial3D
var wall_material: StandardMaterial3D
var obstacle_material_a: StandardMaterial3D
var obstacle_material_b: StandardMaterial3D

func _ready() -> void:
	_create_materials()
	_create_floor()
	_create_walls()
	_create_obstacles()
	print("[World] Generated — Arena: %dx%d, Obstacles: %d" % [arena_size, arena_size, obstacle_count])

func _create_materials() -> void:
	# Floor material
	floor_material = StandardMaterial3D.new()
	floor_material.albedo_color = Color(0.15, 0.15, 0.18)
	floor_material.roughness = 0.8
	floor_material.metallic = 0.1
	floor_material.emission_enabled = true
	floor_material.emission = Color(0.02, 0.05, 0.08)
	floor_material.emission_energy_multiplier = 0.5
	
	# Wall material
	wall_material = StandardMaterial3D.new()
	wall_material.albedo_color = Color(0.1, 0.12, 0.15)
	wall_material.roughness = 0.6
	wall_material.metallic = 0.3
	
	# Obstacle materials
	obstacle_material_a = StandardMaterial3D.new()
	obstacle_material_a.albedo_color = Color(0.2, 0.25, 0.3)
	obstacle_material_a.roughness = 0.5
	obstacle_material_a.metallic = 0.4
	
	obstacle_material_b = StandardMaterial3D.new()
	obstacle_material_b.albedo_color = Color(0.3, 0.15, 0.1)
	obstacle_material_b.roughness = 0.7
	obstacle_material_b.metallic = 0.2

func _create_floor() -> void:
	var floor_body = StaticBody3D.new()
	floor_body.name = "Floor"
	floor_body.collision_layer = 1
	
	var mesh_instance = MeshInstance3D.new()
	var plane_mesh = PlaneMesh.new()
	plane_mesh.size = Vector2(arena_size, arena_size)
	plane_mesh.subdivide_width = 20
	plane_mesh.subdivide_depth = 20
	mesh_instance.mesh = plane_mesh
	mesh_instance.material_override = floor_material
	mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	
	var collision = CollisionShape3D.new()
	var shape = WorldBoundaryShape3D.new()
	collision.shape = shape
	
	floor_body.add_child(mesh_instance)
	floor_body.add_child(collision)
	add_child(floor_body)

func _create_walls() -> void:
	var walls_node = Node3D.new()
	walls_node.name = "Walls"
	
	var half = arena_size / 2.0
	
	_add_wall(walls_node, "WallNorth", Vector3(0, wall_height / 2.0, half), Vector3(arena_size, wall_height, wall_thickness))
	_add_wall(walls_node, "WallSouth", Vector3(0, wall_height / 2.0, -half), Vector3(arena_size, wall_height, wall_thickness))
	_add_wall(walls_node, "WallEast", Vector3(half, wall_height / 2.0, 0), Vector3(wall_thickness, wall_height, arena_size))
	_add_wall(walls_node, "WallWest", Vector3(-half, wall_height / 2.0, 0), Vector3(wall_thickness, wall_height, arena_size))
	
	add_child(walls_node)

func _add_wall(parent: Node3D, wall_name: String, pos: Vector3, size: Vector3) -> void:
	var body = StaticBody3D.new()
	body.name = wall_name
	body.position = pos
	body.collision_layer = 1
	
	var mesh_instance = MeshInstance3D.new()
	var box_mesh = BoxMesh.new()
	box_mesh.size = size
	mesh_instance.mesh = box_mesh
	mesh_instance.material_override = wall_material
	mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	
	var collision = CollisionShape3D.new()
	var box_shape = BoxShape3D.new()
	box_shape.size = size
	collision.shape = box_shape
	
	body.add_child(mesh_instance)
	body.add_child(collision)
	parent.add_child(body)

func _create_obstacles() -> void:
	## Generate random box obstacles with StaticBody3D + CollisionShape3D
	var obstacles_node = Node3D.new()
	obstacles_node.name = "Obstacles"
	
	var rng = RandomNumberGenerator.new()
	rng.seed = 42  # Deterministic
	
	var half = arena_size / 2.0 - 3.0
	
	for i in range(obstacle_count):
		var body = StaticBody3D.new()
		body.name = "Obstacle_%d" % i
		body.collision_layer = 1
		
		# Random position (avoid center spawn area)
		var pos = Vector3.ZERO
		var attempts = 0
		while attempts < 10:
			pos.x = rng.randf_range(-half, half)
			pos.z = rng.randf_range(-half, half)
			if pos.length() > 6.0:  # Keep center clear
				break
			attempts += 1
		
		# Random box size
		var size = Vector3(
			rng.randf_range(1.0, 3.5),
			rng.randf_range(1.0, 3.0),
			rng.randf_range(1.0, 3.5)
		)
		pos.y = size.y / 2.0
		
		# Create mesh
		var mesh_instance = MeshInstance3D.new()
		var box_mesh = BoxMesh.new()
		box_mesh.size = size
		mesh_instance.mesh = box_mesh
		mesh_instance.material_override = obstacle_material_a if i % 2 == 0 else obstacle_material_b
		mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
		
		# Create collision shape
		var collision = CollisionShape3D.new()
		var box_shape = BoxShape3D.new()
		box_shape.size = size
		collision.shape = box_shape
		
		body.position = pos
		body.add_child(mesh_instance)
		body.add_child(collision)
		obstacles_node.add_child(body)
	
	add_child(obstacles_node)

func clear_obstacles() -> void:
	var obstacles = get_node_or_null("Obstacles")
	if obstacles:
		obstacles.queue_free()

func regenerate() -> void:
	clear_obstacles()
	_create_obstacles()
