## Enemy.gd — CharacterBody3D enemy with AI

extends CharacterBody3D

enum EnemyType { BASIC, FAST, TANK }
enum AIState { IDLE, PATROL, CHASE, ATTACK, DEAD }

@export var enemy_type: EnemyType = EnemyType.BASIC
@export var move_speed: float = 3.5
@export var chase_speed: float = 5.0
@export var detection_range: float = 15.0
@export var attack_range: float = 2.0
@export var attack_damage: float = 10.0
@export var attack_cooldown: float = 1.5
@export var max_health: float = 50.0
@export var patrol_radius: float = 10.0
@export var points_value: int = 100

var current_health: float
var _state: AIState = AIState.IDLE
var _player: CharacterBody3D = null
var _gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")
var _patrol_target: Vector3 = Vector3.ZERO
var _patrol_timer: float = 0.0
var _attack_timer: float = 0.0
var _spawn_position: Vector3 = Vector3.ZERO
var _type_name: String = "basic"

signal enemy_died(enemy: CharacterBody3D, points: int, enemy_type_name: String)

func _ready() -> void:
	current_health = max_health
	_spawn_position = global_position
	_patrol_target = _get_random_patrol_point()
	_state = AIState.PATROL
	
	collision_layer = 4  # Layer 3
	collision_mask = 1 | 2  # Layers 1 and 2
	
	# Create collision shape and mesh
	_setup_collision()
	_setup_visual()

func _setup_collision() -> void:
	## Add CollisionShape3D with CapsuleShape3D
	var collision = CollisionShape3D.new()
	collision.name = "CollisionShape3D"
	var capsule_shape = CapsuleShape3D.new()
	
	match enemy_type:
		EnemyType.BASIC:
			capsule_shape.radius = 0.4
			capsule_shape.height = 1.6
		EnemyType.FAST:
			capsule_shape.radius = 0.3
			capsule_shape.height = 1.3
		EnemyType.TANK:
			capsule_shape.radius = 0.6
			capsule_shape.height = 2.0
	
	collision.shape = capsule_shape
	collision.position = Vector3(0, capsule_shape.height / 2.0, 0)
	add_child(collision)

func _setup_visual() -> void:
	var capsule_mesh = CapsuleMesh.new()
	var material = StandardMaterial3D.new()
	
	match enemy_type:
		EnemyType.BASIC:
			capsule_mesh.radius = 0.4
			capsule_mesh.height = 1.6
			material.albedo_color = Color(0.8, 0.15, 0.1)
			_type_name = "basic"
		EnemyType.FAST:
			capsule_mesh.radius = 0.3
			capsule_mesh.height = 1.3
			material.albedo_color = Color(0.9, 0.6, 0.1)
			move_speed = 5.0
			chase_speed = 8.0
			max_health = 30.0
			current_health = max_health
			attack_damage = 5.0
			points_value = 200
			_type_name = "fast"
		EnemyType.TANK:
			capsule_mesh.radius = 0.6
			capsule_mesh.height = 2.0
			material.albedo_color = Color(0.4, 0.1, 0.6)
			move_speed = 2.0
			chase_speed = 3.0
			max_health = 150.0
			current_health = max_health
			attack_damage = 25.0
			attack_cooldown = 2.5
			points_value = 500
			_type_name = "tank"
	
	material.roughness = 0.5
	material.metallic = 0.3
	material.emission_enabled = true
	material.emission = material.albedo_color * 0.3
	material.emission_energy_multiplier = 0.5
	
	var mesh_instance = MeshInstance3D.new()
	mesh_instance.name = "EnemyModel"
	mesh_instance.mesh = capsule_mesh
	mesh_instance.material_override = material
	mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	mesh_instance.position = Vector3(0, capsule_mesh.height / 2.0, 0)
	add_child(mesh_instance)

func _physics_process(delta: float) -> void:
	if _state == AIState.DEAD:
		return
	
	if not is_on_floor():
		velocity.y -= _gravity * delta
	
	if _player == null:
		_player = _find_player()
	
	match _state:
		AIState.IDLE:
			_process_idle(delta)
		AIState.PATROL:
			_process_patrol(delta)
		AIState.CHASE:
			_process_chase(delta)
		AIState.ATTACK:
			_process_attack(delta)
	
	move_and_slide()

func _find_player() -> CharacterBody3D:
	var players = get_tree().get_nodes_in_group("player")
	if players.size() > 0:
		return players[0] as CharacterBody3D
	return null

func _process_idle(delta: float) -> void:
	_patrol_timer += delta
	if _patrol_timer >= 2.0:
		_patrol_timer = 0.0
		_state = AIState.PATROL
		_patrol_target = _get_random_patrol_point()

func _process_patrol(delta: float) -> void:
	var direction = (_patrol_target - global_position)
	direction.y = 0
	
	if direction.length() < 1.5:
		_state = AIState.IDLE
		_patrol_timer = 0.0
		return
	
	direction = direction.normalized()
	velocity.x = direction.x * move_speed
	velocity.z = direction.z * move_speed
	
	if direction.length() > 0.01:
		look_at(global_position + direction, Vector3.UP)
	
	if _player and _can_detect_player():
		_state = AIState.CHASE

func _process_chase(delta: float) -> void:
	if _player == null:
		_state = AIState.PATROL
		return
	
	var direction = (_player.global_position - global_position)
	direction.y = 0
	var distance = direction.length()
	
	if distance > detection_range * 1.5:
		_state = AIState.PATROL
		_patrol_target = _get_random_patrol_point()
		return
	
	if distance < attack_range:
		_state = AIState.ATTACK
		_attack_timer = 0.0
		velocity.x = 0
		velocity.z = 0
		return
	
	direction = direction.normalized()
	velocity.x = direction.x * chase_speed
	velocity.z = direction.z * chase_speed
	
	if direction.length() > 0.01:
		look_at(global_position + direction, Vector3.UP)

func _process_attack(delta: float) -> void:
	if _player == null:
		_state = AIState.PATROL
		return
	
	_attack_timer += delta
	
	var distance = global_position.distance_to(_player.global_position)
	
	if distance > attack_range * 1.5:
		_state = AIState.CHASE
		return
	
	if _attack_timer >= attack_cooldown:
		_attack_timer = 0.0
		_perform_attack()

func _perform_attack() -> void:
	if _player and _player.has_method("take_damage"):
		_player.take_damage(attack_damage, _type_name)

func _can_detect_player() -> bool:
	if _player == null:
		return false
	return global_position.distance_to(_player.global_position) <= detection_range

func _get_random_patrol_point() -> Vector3:
	var rng = RandomNumberGenerator.new()
	var angle = rng.randf_range(0, TAU)
	var radius = rng.randf_range(3.0, patrol_radius)
	return _spawn_position + Vector3(cos(angle) * radius, 0, sin(angle) * radius)

func take_damage(amount: float) -> void:
	current_health -= amount
	
	var model = get_node_or_null("EnemyModel")
	if model and model is MeshInstance3D:
		var mat = model.material_override as StandardMaterial3D
		if mat:
			mat.emission_energy_multiplier = 3.0
			get_tree().create_timer(0.1).timeout.connect(func():
				if mat:
					mat.emission_energy_multiplier = 0.5
			)
	
	if current_health <= 0:
		_die()
	else:
		_state = AIState.CHASE

func _die() -> void:
	_state = AIState.DEAD
	enemy_died.emit(self, points_value, _type_name)
	
	var tween = create_tween()
	tween.tween_property(self, "scale", Vector3(0.01, 0.01, 0.01), 0.3)
	tween.tween_callback(queue_free)

func apply_difficulty(difficulty_level: int) -> void:
	var scale_factor = 1.0 + (difficulty_level - 1) * 0.15
	chase_speed *= scale_factor
	attack_damage *= scale_factor
	max_health *= scale_factor
	current_health = max_health
	detection_range *= (1.0 + (difficulty_level - 1) * 0.05)
