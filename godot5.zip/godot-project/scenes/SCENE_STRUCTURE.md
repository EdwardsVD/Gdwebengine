# Scene Files — Create These in Godot Editor

## Main.tscn (Primary Scene)

```tscn
[gd_scene format=3]

[node name="Main" type="Node3D"]
script = ExtResource("scripts/Main.gd")

[node name="WorldEnvironment" type="WorldEnvironment" parent="."]
environment = SubResource("Environment_xxxxx")
# See LightingSetup.gd for all environment properties

[node name="SunLight" type="DirectionalLight3D" parent="."]
transform = Transform3D(...)  # rotation_degrees = (-45, 30, 0)
light_color = Color(0.9, 0.85, 0.75, 1)
light_energy = 0.8
shadow_enabled = true
shadow_bias = 0.03
shadow_normal_bias = 2.0
directional_shadow_mode = 2  # PARALLEL_4_SPLITS

[node name="FillLight" type="DirectionalLight3D" parent="."]
transform = Transform3D(...)  # rotation_degrees = (-30, -150, 0)
light_color = Color(0.3, 0.35, 0.5, 1)
light_energy = 0.2

[node name="World" type="Node3D" parent="."]
script = ExtResource("scripts/World.gd")
arena_size = 50.0
wall_height = 5.0
obstacle_count = 20

[node name="Player" type="CharacterBody3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0)  # pos=(0,1,0)
script = ExtResource("scripts/Player.gd")
collision_layer = 2
collision_mask = 5  # layers 1 + 3

[node name="CollisionShape3D" type="CollisionShape3D" parent="Player"]
shape = SubResource("CapsuleShape3D_player")  # radius=0.4, height=1.8

[node name="PlayerModel" type="MeshInstance3D" parent="Player"]
mesh = SubResource("CapsuleMesh_player")  # radius=0.4, height=1.8
material_override = SubResource("StandardMaterial3D_player")  # albedo=cyan

[node name="CameraMount" type="Node3D" parent="Player"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.8, 0)  # eye level
script = ExtResource("scripts/PlayerCamera.gd")

[node name="Camera3D" type="Camera3D" parent="Player/CameraMount"]
current = true
fov = 75.0
near = 0.05
far = 500.0

[node name="EnemySpawner" type="Node3D" parent="."]
```

## Enemy.tscn (Instantiated at Runtime)

```tscn
[gd_scene format=3]

[node name="Enemy" type="CharacterBody3D"]
script = ExtResource("scripts/Enemy.gd")
collision_layer = 4  # layer 3
collision_mask = 3  # layers 1 + 2

[node name="CollisionShape3D" type="CollisionShape3D" parent="."]
shape = SubResource("CapsuleShape3D")  # radius=0.4, height=1.6

[node name="EnemyModel" type="MeshInstance3D" parent="."]
mesh = SubResource("CapsuleMesh")  # radius=0.4, height=1.6
material_override = SubResource("StandardMaterial3D")  # albedo=red

# Note: In the current implementation, Enemy.gd creates its own
# mesh and collision shape in _setup_visual(), so you can either:
# A) Create Enemy.tscn with pre-built nodes (above)
# B) Use a bare CharacterBody3D and let the script build everything
```

## How to Create Scenes

### Option A: Manual in Editor
1. Open Godot Editor
2. Scene → New Scene → Node3D (for Main)
3. Add child nodes matching the hierarchy above
4. Attach scripts to appropriate nodes
5. Save as .tscn files

### Option B: Programmatic (Current approach)
The scripts create most nodes at runtime:
- `World.gd` generates floor, walls, and obstacles
- `Enemy.gd` generates its own mesh and collision
- `LightingSetup.gd` can generate environment and lights
- Only the base hierarchy (Main, Player, Camera) needs manual setup
